#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import logging
import random
import os
import time
import sys
import base64
from io import BytesIO
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, InputMediaPhoto, ParseMode
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters, CallbackContext, CallbackQueryHandler, ConversationHandler
from telegram.error import NetworkError, TelegramError
from chemistry_data import ELEMENTS, COMPOUNDS, CONCEPTS, QUIZ_QUESTIONS, PERIODIC_TABLE_INFO, CHEMICAL_CALCULATIONS_INFO, CHEMICAL_BONDS_INFO
from quiz_db import QuizDatabase
from chemical_equations import process_text_with_chemical_notation, format_chemical_equation

# --- إعدادات --- 
# ضع معرف المستخدم الرقمي الخاص بك هنا لتقييد الوصول إلى إدارة قاعدة البيانات
ADMIN_USER_ID = 6448526509 # استبدل None بمعرف المستخدم الرقمي الخاص بك (مثال: 123456789)
# توكن البوت
TOKEN = "8180063810:AAEvlP5y0lxLvMWgtJTb4x3Z7wwG-nhH97Y"
# تكوين التسجيل
log_file_path = os.path.join(os.path.dirname(__file__), 'bot_log.txt')
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO,
    handlers=[
        logging.FileHandler(log_file_path, encoding='utf-8'), # تسجيل في ملف فقط
        # logging.StreamHandler(sys.stdout) # تم التعليق لتجنب الازدواجية عند استخدام nohup
    ]
)
logger = logging.getLogger(__name__)

# تهيئة قاعدة بيانات الأسئلة
QUIZ_DB = QuizDatabase(os.path.join(os.path.dirname(__file__), 'questions.json'))

# حالات المحادثة لإضافة سؤال وحذف/عرض سؤال
(QUESTION, OPTIONS, CORRECT_ANSWER, EXPLANATION, CHAPTER, LESSON, 
 DELETE_CONFIRM, SHOW_INDEX) = range(8)

# --- وظائف التحقق من الصلاحيات ---
def is_admin(user_id: int) -> bool:
    """التحقق مما إذا كان المستخدم هو المسؤول."""
    if ADMIN_USER_ID is None:
        logger.warning("ADMIN_USER_ID غير معين. سيتم السماح للجميع بإدارة قاعدة البيانات.")
        return True # السماح للجميع إذا لم يتم تعيين المسؤول
    return user_id == ADMIN_USER_ID

# --- الدوال المساعدة للقوائم ---
def show_main_menu(update: Update, context: CallbackContext, message_text: str = None) -> None:
    """عرض القائمة الرئيسية مع الأزرار."""
    keyboard = [
        [InlineKeyboardButton("📚 المعلومات الكيميائية", callback_data='menu_info')],
        [InlineKeyboardButton("📝 الاختبارات", callback_data='menu_quiz')],
        [InlineKeyboardButton("ℹ️ حول البوت", callback_data='menu_about')],
    ]
    if is_admin(update.effective_user.id):
        keyboard.append([InlineKeyboardButton("⚙️ إدارة الأسئلة", callback_data='menu_admin')])

    reply_markup = InlineKeyboardMarkup(keyboard)

    if message_text is None:
        user = update.effective_user
        message_text = (
            f"مرحباً بك في بوت الكيمياء التحصيلي 🧪\n\n"
            f"أهلاً {user.first_name}! 👋\n\n"
            f"اختر أحد الخيارات أدناه:"
        )

    # إذا كان التحديث من callback_query، استخدم edit_message_text
    if update.callback_query:
        try:
            update.callback_query.edit_message_text(message_text, reply_markup=reply_markup, parse_mode=ParseMode.HTML)
        except TelegramError as e:
            # تجاهل الخطأ إذا كانت الرسالة لم تتغير
            if "Message is not modified" not in str(e):
                logger.error(f"Error editing message: {e}")
                # محاولة إرسال رسالة جديدة كحل بديل
                update.effective_message.reply_text(message_text, reply_markup=reply_markup, parse_mode=ParseMode.HTML)
    # إذا كان التحديث من رسالة (مثل /start)، استخدم reply_text
    elif update.message:
        update.message.reply_text(message_text, reply_markup=reply_markup, parse_mode=ParseMode.HTML)

def show_info_menu(update: Update, context: CallbackContext) -> None:
    """عرض قائمة المعلومات الكيميائية."""
    keyboard = [
        [InlineKeyboardButton("عنصر كيميائي", callback_data='info_element_prompt')],
        [InlineKeyboardButton("مركب كيميائي", callback_data='info_compound_prompt')],
        [InlineKeyboardButton("مفهوم كيميائي", callback_data='info_concept_prompt')],
        [InlineKeyboardButton("الجدول الدوري", callback_data='info_periodic')],
        [InlineKeyboardButton("الحسابات الكيميائية", callback_data='info_calculations')],
        [InlineKeyboardButton("الروابط الكيميائية", callback_data='info_bonds')],
        [InlineKeyboardButton("🔙 العودة للقائمة الرئيسية", callback_data='main_menu')],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    update.callback_query.edit_message_text("📚 اختر نوع المعلومات الكيميائية:", reply_markup=reply_markup)

def show_quiz_menu(update: Update, context: CallbackContext) -> None:
    """عرض قائمة الاختبارات."""
    keyboard = [
        [InlineKeyboardButton("اختبار تحصيلي عام (مخصص)", callback_data='quiz_tahseely')],
        [InlineKeyboardButton("اختبار حسب الفصل (مخصص)", callback_data='quiz_chapter_select')],
        [InlineKeyboardButton("اختبار حسب الدرس (مخصص)", callback_data='quiz_lesson_select_chapter')],
        [InlineKeyboardButton("اختبار قصير (مضمن)", callback_data='quiz_builtin')],
        [InlineKeyboardButton("🔙 العودة للقائمة الرئيسية", callback_data='main_menu')],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    update.callback_query.edit_message_text("📝 اختر نوع الاختبار:", reply_markup=reply_markup)

def show_admin_menu(update: Update, context: CallbackContext) -> None:
    """عرض قائمة إدارة الأسئلة للمسؤول."""
    if not is_admin(update.effective_user.id):
        update.callback_query.answer("عذراً، هذا القسم متاح للمسؤول فقط.", show_alert=True)
        return

    keyboard = [
        [InlineKeyboardButton("➕ إضافة سؤال جديد", callback_data='admin_add')],
        [InlineKeyboardButton("📥 استيراد أسئلة", callback_data='admin_import_questions')],
        [InlineKeyboardButton("📤 تصدير أسئلة", callback_data='admin_export_questions')],
        [InlineKeyboardButton("📄 إنشاء قالب", callback_data='admin_create_template')],
        [InlineKeyboardButton("📋 عرض قائمة الأسئلة", callback_data='admin_list')],
        [InlineKeyboardButton("🗑️ حذف سؤال", callback_data='admin_delete_prompt')],
        [InlineKeyboardButton("ℹ️ عرض سؤال معين", callback_data='admin_show_prompt')],
        [InlineKeyboardButton("🔙 العودة للقائمة الرئيسية", callback_data='main_menu')],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    update.callback_query.edit_message_text("⚙️ اختر عملية إدارة الأسئلة:", reply_markup=reply_markup)

# --- الدوال المساعدة الأساسية (معدلة للقوائم) ---
def start(update: Update, context: CallbackContext) -> None:
    """إرسال رسالة عند تنفيذ أمر /start وعرض القائمة الرئيسية."""
    show_main_menu(update, context)

def help_command(update: Update, context: CallbackContext) -> None:
    """عرض القائمة الرئيسية عند تنفيذ أمر /help."""
    show_main_menu(update, context, message_text="القائمة الرئيسية 👇")

def about_command(update: Update, context: CallbackContext) -> None:
    """إرسال معلومات عن البوت عند الضغط على زر 'حول البوت'."""
    about_text = (
        "<b>بوت كيمياء تحصيلي 🧪</b>\n\n"
        "هذا البوت مصمم لمساعدة الطلاب في دراسة الكيمياء والتحضير للاختبارات التحصيلية.\n"
        "<b>تحت إشراف الأستاذ حسين الموسى</b>\n\n"
        "<b>يمكن للبوت تقديم:</b>\n"
        "• معلومات عن العناصر والمركبات الكيميائية\n"
        "• شرح للمفاهيم الأساسية في الكيمياء\n"
        "• اختبارات تجريبية متنوعة (مضمنة ومخصصة حسب الفصل والدرس)\n"
        "• معلومات عن الجدول الدوري\n"
        "• مساعدة في الحسابات الكيميائية\n"
        "• شرح أنواع الروابط الكيميائية\n"
        "• إمكانية إضافة أسئلة اختبارية مخصصة (للمسؤول فقط)\n\n"
        "استخدم الأزرار للتنقل بين الخيارات." 
    )
    keyboard = [[InlineKeyboardButton("🔙 العودة للقائمة الرئيسية", callback_data='main_menu')]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    # التحقق إذا كان التحديث من callback_query أو message
    if update.callback_query:
        update.callback_query.edit_message_text(about_text, reply_markup=reply_markup, parse_mode=ParseMode.HTML)
    elif update.message: # في حال استدعاء /about مباشرة (غير مرجح مع الأزرار)
         update.message.reply_text(about_text, reply_markup=reply_markup, parse_mode=ParseMode.HTML)

def id_command(update: Update, context: CallbackContext) -> None:
    """إرسال معرف المستخدم عند تنفيذ أمر /id."""
    user_id = update.effective_user.id
    update.message.reply_text(f"معرف المستخدم الخاص بك هو: {user_id}")

# --- معالجات أزرار القوائم الرئيسية ---
def main_menu_button_handler(update: Update, context: CallbackContext) -> None:
    """معالجة الضغط على أزرار القائمة الرئيسية وقوائم فرعية أخرى."""
    query = update.callback_query
    query.answer()
    data = query.data

    if data == 'main_menu':
        show_main_menu(update, context, message_text="القائمة الرئيسية 👇")
    elif data == 'menu_info':
        show_info_menu(update, context)
    elif data == 'menu_quiz':
        show_quiz_menu(update, context)
    elif data == 'menu_about':
        about_command(update, context)
    elif data == 'menu_admin':
        show_admin_menu(update, context)
    # --- معالجات أزرار قائمة المعلومات ---
    elif data == 'info_element_prompt':
        query.message.reply_text("الرجاء إرسال اسم العنصر الذي تريد البحث عنه (مثال: هيدروجين)")
        context.user_data['next_action'] = 'search_element'
    elif data == 'info_compound_prompt':
        query.message.reply_text("الرجاء إرسال اسم المركب الذي تريد البحث عنه (مثال: ماء)")
        context.user_data['next_action'] = 'search_compound'
    elif data == 'info_concept_prompt':
        query.message.reply_text("الرجاء إرسال اسم المفهوم الذي تريد البحث عنه (مثال: الذرة)")
        context.user_data['next_action'] = 'search_concept'
    elif data == 'info_periodic':
        periodic_table_command(update, context)
    elif data == 'info_calculations':
        calculations_command(update, context)
    elif data == 'info_bonds':
        bonds_command(update, context)
    # --- معالجات أزرار قائمة الاختبارات ---
    elif data == 'quiz_builtin':
        quiz_command(update, context)
    elif data == 'quiz_tahseely':
        custom_quiz_start(update, context, quiz_type='all')
    elif data == 'quiz_chapter_select':
        custom_quiz_select_chapter(update, context)
    elif data == 'quiz_lesson_select_chapter':
        custom_quiz_select_lesson_chapter(update, context)
    elif data.startswith('quiz_select_chapter_'):
        chapter = data.replace('quiz_select_chapter_', '')
        custom_quiz_start(update, context, quiz_type='chapter', category=chapter)
    elif data.startswith('quiz_select_lesson_chapter_'):
        chapter = data.replace('quiz_select_lesson_chapter_', '')
        custom_quiz_select_lesson(update, context, chapter)
    elif data.startswith('quiz_select_lesson_'):
        parts = data.replace('quiz_select_lesson_', '').split('|', 1)
        chapter = parts[0]
        lesson = parts[1]
        custom_quiz_start(update, context, quiz_type='lesson', category=lesson, chapter=chapter)
    # --- معالجات أزرار قائمة الإدارة ---
    elif data == 'admin_add':
        # بدء محادثة إضافة السؤال
        add_question_start(update, context)
    elif data == 'admin_list':
        list_questions(update, context)
    elif data == 'admin_delete_prompt':
        # بدء محادثة حذف السؤال
        delete_question_prompt(update, context)
    elif data == 'admin_show_prompt':
        # بدء محادثة عرض السؤال
        show_question_prompt(update, context)
    elif data == 'admin_import_questions':
        # بدء محادثة استيراد الأسئلة
        import_questions_prompt(update, context)
    elif data == 'admin_export_questions':
        # بدء محادثة تصدير الأسئلة
        export_questions_prompt(update, context)
    elif data == 'admin_create_template':
        # بدء محادثة إنشاء قالب
        create_template_prompt(update, context)

def handle_text_input(update: Update, context: CallbackContext) -> None:
    """معالجة إدخال النص بعد طلب البحث عن عنصر/مركب/مفهوم."""
    # تجاهل إذا كانت الرسالة من محادثة نشطة (مثل إضافة سؤال)
    if ConversationHandler.check_update(update):
        return
        
    if 'next_action' in context.user_data:
        action = context.user_data.pop('next_action')
        text = update.message.text
        # إعادة استخدام الدوال الموجودة مع تعديل بسيط
        if action == 'search_element':
            element_command(update, context, element_name=text)
        elif action == 'search_compound':
            compound_command(update, context, compound_name=text)
        elif action == 'search_concept':
            concept_command(update, context, concept_name=text)
        elif action == 'delete_question_index':
             delete_question_confirm(update, context, index_str=text)
        elif action == 'show_question_index':
             show_question(update, context, index_str=text)
    else:
        # التعامل مع الرسائل النصية العادية الأخرى إذا لزم الأمر
        # update.message.reply_text("لم أفهم طلبك. استخدم الأزرار أو الأوامر المتاحة.")
        pass # تجاهل الرسائل النصية غير المتوقعة

# --- دوال المعلومات الكيميائية (معدلة لاستقبال الاسم مباشرة وعرض زر العودة) ---
def element_command(update: Update, context: CallbackContext, element_name: str = None) -> None:
    """إرسال معلومات عن عنصر كيميائي."""
    message = update.effective_message # استخدام الرسالة الفعالة (قد تكون من callback query)
    if element_name is None: # إذا تم استدعاؤه كأمر نصي
        if not context.args:
            message.reply_text(
                "الرجاء إدخال اسم العنصر بعد الأمر. مثال: /element هيدروجين"
            )
            return
        element_name = " ".join(context.args)

    if element_name in ELEMENTS:
        element = ELEMENTS[element_name]
        response = (
            f"<b>🔍 معلومات عن عنصر {element_name}:</b>\n\n"
            f"<b>الرمز:</b> {element['رمز']}\n"
            f"<b>الرقم الذري:</b> {element['رقم_ذري']}\n"
            f"<b>الوزن الذري:</b> {element['وزن_ذري']} وحدة كتل ذرية"
        )
    else:
        response = f"عذراً، لم أجد معلومات عن العنصر '{element_name}'. تأكد من كتابة اسم العنصر بشكل صحيح."
    
    keyboard = [[InlineKeyboardButton("🔙 العودة لقائمة المعلومات", callback_data='menu_info')]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    message.reply_text(response, reply_markup=reply_markup, parse_mode=ParseMode.HTML)

def compound_command(update: Update, context: CallbackContext, compound_name: str = None) -> None:
    """إرسال معلومات عن مركب كيميائي."""
    message = update.effective_message
    if compound_name is None:
        if not context.args:
            message.reply_text(
                "الرجاء إدخال اسم المركب بعد الأمر. مثال: /compound ماء"
            )
            return
        compound_name = " ".join(context.args)

    if compound_name in COMPOUNDS:
        compound = COMPOUNDS[compound_name]
        response = (
            f"<b>🧪 معلومات عن مركب {compound_name}:</b>\n\n"
            f"<b>الصيغة الكيميائية:</b> {compound['صيغة']}\n"
            f"<b>النوع:</b> {compound['نوع']}\n"
            f"<b>الحالة الفيزيائية:</b> {compound['حالة']}"
        )
    else:
        response = f"عذراً، لم أجد معلومات عن المركب '{compound_name}'. تأكد من كتابة اسم المركب بشكل صحيح."
    
    keyboard = [[InlineKeyboardButton("🔙 العودة لقائمة المعلومات", callback_data='menu_info')]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    message.reply_text(response, reply_markup=reply_markup, parse_mode=ParseMode.HTML)

def concept_command(update: Update, context: CallbackContext, concept_name: str = None) -> None:
    """إرسال شرح لمفهوم كيميائي."""
    message = update.effective_message
    if concept_name is None:
        if not context.args:
            message.reply_text(
                "الرجاء إدخال اسم المفهوم بعد الأمر. مثال: /concept الذرة"
            )
            return
        concept_name = " ".join(context.args)

    if concept_name in CONCEPTS:
        concept = CONCEPTS[concept_name]
        response = (
            f"<b>📖 شرح مفهوم {concept_name}:</b>\n\n"
            f"{concept['شرح']}"
        )
    else:
        response = f"عذراً، لم أجد معلومات عن المفهوم '{concept_name}'. تأكد من كتابة اسم المفهوم بشكل صحيح."
    
    keyboard = [[InlineKeyboardButton("🔙 العودة لقائمة المعلومات", callback_data='menu_info')]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    message.reply_text(response, reply_markup=reply_markup, parse_mode=ParseMode.HTML)

def periodic_table_command(update: Update, context: CallbackContext) -> None:
    """إرسال معلومات عن الجدول الدوري."""
    query = update.callback_query
    query.answer()
    
    response = (
        "<b>📊 الجدول الدوري للعناصر</b>\n\n"
        f"{PERIODIC_TABLE_INFO}"
    )
    
    keyboard = [[InlineKeyboardButton("🔙 العودة لقائمة المعلومات", callback_data='menu_info')]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    query.edit_message_text(response, reply_markup=reply_markup, parse_mode=ParseMode.HTML)

def calculations_command(update: Update, context: CallbackContext) -> None:
    """إرسال معلومات عن الحسابات الكيميائية."""
    query = update.callback_query
    query.answer()
    
    response = (
        "<b>🧮 الحسابات الكيميائية</b>\n\n"
        f"{CHEMICAL_CALCULATIONS_INFO}"
    )
    
    keyboard = [[InlineKeyboardButton("🔙 العودة لقائمة المعلومات", callback_data='menu_info')]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    query.edit_message_text(response, reply_markup=reply_markup, parse_mode=ParseMode.HTML)

def bonds_command(update: Update, context: CallbackContext) -> None:
    """إرسال معلومات عن الروابط الكيميائية."""
    query = update.callback_query
    query.answer()
    
    response = (
        "<b>🔗 الروابط الكيميائية</b>\n\n"
        f"{CHEMICAL_BONDS_INFO}"
    )
    
    keyboard = [[InlineKeyboardButton("🔙 العودة لقائمة المعلومات", callback_data='menu_info')]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    query.edit_message_text(response, reply_markup=reply_markup, parse_mode=ParseMode.HTML)

# --- دوال الاختبارات ---
def quiz_command(update: Update, context: CallbackContext) -> None:
    """بدء اختبار قصير مضمن."""
    query = update.callback_query
    query.answer()
    
    # اختيار 5 أسئلة عشوائية من الأسئلة المضمنة
    questions = random.sample(QUIZ_QUESTIONS, min(5, len(QUIZ_QUESTIONS)))
    context.user_data['quiz'] = {
        'questions': questions,
        'current_question': 0,
        'score': 0,
        'total': len(questions)
    }
    
    # عرض السؤال الأول
    send_quiz_question(update, context)

def custom_quiz_select_chapter(update: Update, context: CallbackContext) -> None:
    """عرض قائمة الفصول للاختيار منها للاختبار."""
    query = update.callback_query
    query.answer()
    
    # الحصول على قائمة الفصول المتاحة
    chapters = QUIZ_DB.get_chapters()
    
    if not chapters:
        query.edit_message_text(
            "لا توجد أسئلة مخصصة متاحة حالياً. يرجى التواصل مع المسؤول لإضافة أسئلة.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 العودة لقائمة الاختبارات", callback_data='menu_quiz')]])
        )
        return
    
    # إنشاء أزرار للفصول
    keyboard = []
    for chapter in chapters:
        keyboard.append([InlineKeyboardButton(f"الفصل {chapter}", callback_data=f'quiz_select_chapter_{chapter}')])
    
    keyboard.append([InlineKeyboardButton("🔙 العودة لقائمة الاختبارات", callback_data='menu_quiz')])
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    query.edit_message_text("اختر الفصل للاختبار:", reply_markup=reply_markup)

def custom_quiz_select_lesson_chapter(update: Update, context: CallbackContext) -> None:
    """عرض قائمة الفصول للاختيار منها لاختبار حسب الدرس."""
    query = update.callback_query
    query.answer()
    
    # الحصول على قائمة الفصول المتاحة
    chapters = QUIZ_DB.get_chapters()
    
    if not chapters:
        query.edit_message_text(
            "لا توجد أسئلة مخصصة متاحة حالياً. يرجى التواصل مع المسؤول لإضافة أسئلة.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 العودة لقائمة الاختبارات", callback_data='menu_quiz')]])
        )
        return
    
    # إنشاء أزرار للفصول
    keyboard = []
    for chapter in chapters:
        keyboard.append([InlineKeyboardButton(f"الفصل {chapter}", callback_data=f'quiz_select_lesson_chapter_{chapter}')])
    
    keyboard.append([InlineKeyboardButton("🔙 العودة لقائمة الاختبارات", callback_data='menu_quiz')])
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    query.edit_message_text("اختر الفصل أولاً:", reply_markup=reply_markup)

def custom_quiz_select_lesson(update: Update, context: CallbackContext, chapter: str) -> None:
    """عرض قائمة الدروس للاختيار منها للاختبار."""
    query = update.callback_query
    query.answer()
    
    # الحصول على قائمة الدروس المتاحة للفصل المحدد
    lessons = QUIZ_DB.get_lessons(chapter)
    
    if not lessons:
        query.edit_message_text(
            f"لا توجد دروس متاحة للفصل {chapter}. يرجى التواصل مع المسؤول لإضافة أسئلة.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 العودة لاختيار الفصل", callback_data='quiz_lesson_select_chapter')]])
        )
        return
    
    # إنشاء أزرار للدروس
    keyboard = []
    for lesson in lessons:
        keyboard.append([InlineKeyboardButton(f"الدرس {lesson}", callback_data=f'quiz_select_lesson_{chapter}|{lesson}')])
    
    keyboard.append([InlineKeyboardButton("🔙 العودة لاختيار الفصل", callback_data='quiz_lesson_select_chapter')])
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    query.edit_message_text(f"اختر الدرس من الفصل {chapter}:", reply_markup=reply_markup)

def custom_quiz_start(update: Update, context: CallbackContext, quiz_type: str, category: str = None, chapter: str = None) -> None:
    """بدء اختبار مخصص حسب النوع والفئة."""
    query = update.callback_query
    query.answer()
    
    # الحصول على الأسئلة المناسبة
    if quiz_type == 'all':
        questions = QUIZ_DB.get_all_questions()
    elif quiz_type == 'chapter':
        questions = QUIZ_DB.get_questions_by_chapter(category)
    elif quiz_type == 'lesson':
        questions = QUIZ_DB.get_questions_by_lesson(chapter, category)
    else:
        query.edit_message_text(
            "خطأ في نوع الاختبار. يرجى المحاولة مرة أخرى.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 العودة لقائمة الاختبارات", callback_data='menu_quiz')]])
        )
        return
    
    if not questions:
        query.edit_message_text(
            "لا توجد أسئلة متاحة لهذا الاختيار. يرجى التواصل مع المسؤول لإضافة أسئلة.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 العودة لقائمة الاختبارات", callback_data='menu_quiz')]])
        )
        return
    
    # اختيار 5 أسئلة عشوائية (أو أقل إذا كان العدد المتاح أقل)
    selected_questions = random.sample(questions, min(5, len(questions)))
    
    context.user_data['quiz'] = {
        'questions': selected_questions,
        'current_question': 0,
        'score': 0,
        'total': len(selected_questions),
        'custom': True
    }
    
    # عرض السؤال الأول
    send_quiz_question(update, context)

def send_quiz_question(update: Update, context: CallbackContext) -> None:
    """إرسال سؤال الاختبار الحالي."""
    quiz_data = context.user_data.get('quiz', {})
    current_index = quiz_data.get('current_question', 0)
    questions = quiz_data.get('questions', [])
    
    if not questions or current_index >= len(questions):
        # انتهاء الاختبار
        send_quiz_results(update, context)
        return
    
    question_data = questions[current_index]
    
    # التعامل مع الأسئلة المضمنة والمخصصة بشكل مختلف
    if quiz_data.get('custom', False):
        # سؤال مخصص
        question_text = question_data.get('question', '')
        options = question_data.get('options', [])
        
        # معالجة المعادلات الكيميائية في السؤال والخيارات
        question_text = process_text_with_chemical_notation(question_text)
        options = [process_text_with_chemical_notation(opt) for opt in options]
    else:
        # سؤال مضمن
        question_text = question_data.get('سؤال', '')
        options = question_data.get('خيارات', [])
    
    # إنشاء أزرار للخيارات
    keyboard = []
    for i, option in enumerate(options):
        keyboard.append([InlineKeyboardButton(f"{chr(65+i)}. {option}", callback_data=f'quiz_answer_{i}')])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    message_text = (
        f"<b>السؤال {current_index + 1} من {len(questions)}:</b>\n\n"
        f"{question_text}"
    )
    
    # إرسال السؤال
    if update.callback_query:
        update.callback_query.edit_message_text(message_text, reply_markup=reply_markup, parse_mode=ParseMode.HTML)
    else:
        update.effective_message.reply_text(message_text, reply_markup=reply_markup, parse_mode=ParseMode.HTML)

def handle_quiz_answer(update: Update, context: CallbackContext) -> None:
    """معالجة إجابة المستخدم على سؤال الاختبار."""
    query = update.callback_query
    query.answer()
    
    # استخراج رقم الإجابة المختارة
    answer_index = int(query.data.replace('quiz_answer_', ''))
    
    quiz_data = context.user_data.get('quiz', {})
    current_index = quiz_data.get('current_question', 0)
    questions = quiz_data.get('questions', [])
    
    if not questions or current_index >= len(questions):
        # حالة خطأ - انتهاء الاختبار
        send_quiz_results(update, context)
        return
    
    question_data = questions[current_index]
    
    # التحقق من الإجابة
    if quiz_data.get('custom', False):
        # سؤال مخصص
        correct_answer_index = question_data.get('correct_answer', 0)
        explanation = question_data.get('explanation', '')
    else:
        # سؤال مضمن
        correct_answer_index = question_data.get('الإجابة_الصحيحة', 0)
        explanation = question_data.get('الشرح', '')
    
    is_correct = (answer_index == correct_answer_index)
    
    if is_correct:
        quiz_data['score'] += 1
    
    # عرض نتيجة الإجابة
    if quiz_data.get('custom', False):
        options = question_data.get('options', [])
    else:
        options = question_data.get('خيارات', [])
    
    correct_option = options[correct_answer_index]
    selected_option = options[answer_index]
    
    # معالجة المعادلات الكيميائية في الشرح والخيارات
    explanation = process_text_with_chemical_notation(explanation)
    correct_option = process_text_with_chemical_notation(correct_option)
    selected_option = process_text_with_chemical_notation(selected_option)
    
    result_text = (
        f"<b>{'✅ إجابة صحيحة!' if is_correct else '❌ إجابة خاطئة!'}</b>\n\n"
        f"<b>إجابتك:</b> {selected_option}\n"
        f"<b>الإجابة الصحيحة:</b> {correct_option}\n\n"
        f"<b>الشرح:</b>\n{explanation}"
    )
    
    # التقدم للسؤال التالي
    quiz_data['current_question'] += 1
    context.user_data['quiz'] = quiz_data
    
    keyboard = [[InlineKeyboardButton("التالي ⏭️", callback_data='quiz_next')]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    query.edit_message_text(result_text, reply_markup=reply_markup, parse_mode=ParseMode.HTML)

def handle_quiz_next(update: Update, context: CallbackContext) -> None:
    """الانتقال إلى السؤال التالي في الاختبار."""
    query = update.callback_query
    query.answer()
    
    # عرض السؤال التالي
    send_quiz_question(update, context)

def send_quiz_results(update: Update, context: CallbackContext) -> None:
    """إرسال نتائج الاختبار النهائية."""
    quiz_data = context.user_data.get('quiz', {})
    score = quiz_data.get('score', 0)
    total = quiz_data.get('total', 0)
    
    percentage = (score / total * 100) if total > 0 else 0
    
    result_text = (
        f"<b>🏁 انتهى الاختبار!</b>\n\n"
        f"<b>النتيجة:</b> {score} من {total} ({percentage:.1f}%)\n\n"
    )
    
    if percentage >= 80:
        result_text += "🌟 ممتاز! أداء رائع!"
    elif percentage >= 60:
        result_text += "👍 جيد جداً! استمر في التحسن."
    else:
        result_text += "📚 استمر في المذاكرة والتدريب!"
    
    keyboard = [[InlineKeyboardButton("🔙 العودة للقائمة الرئيسية", callback_data='main_menu')]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    if update.callback_query:
        update.callback_query.edit_message_text(result_text, reply_markup=reply_markup, parse_mode=ParseMode.HTML)
    else:
        update.effective_message.reply_text(result_text, reply_markup=reply_markup, parse_mode=ParseMode.HTML)
    
    # مسح بيانات الاختبار
    if 'quiz' in context.user_data:
        del context.user_data['quiz']

# --- دوال إدارة الأسئلة ---
def add_question_start(update: Update, context: CallbackContext) -> int:
    """بدء محادثة إضافة سؤال جديد."""
    query = update.callback_query
    
    if not is_admin(update.effective_user.id):
        query.answer("عذراً، هذا القسم متاح للمسؤول فقط.", show_alert=True)
        return ConversationHandler.END
    
    query.answer()
    query.edit_message_text(
        "🆕 إضافة سؤال جديد\n\n"
        "الرجاء إرسال نص السؤال:"
    )
    
    return QUESTION

def add_question_options(update: Update, context: CallbackContext) -> int:
    """استلام نص السؤال وطلب الخيارات."""
    context.user_data['new_question'] = {'question': update.message.text}
    
    update.message.reply_text(
        "تم استلام نص السؤال.\n\n"
        "الآن، الرجاء إرسال خيارات الإجابة مفصولة بسطر جديد (4 خيارات):"
    )
    
    return OPTIONS

def add_question_correct_answer(update: Update, context: CallbackContext) -> int:
    """استلام الخيارات وطلب الإجابة الصحيحة."""
    options_text = update.message.text
    options = [option.strip() for option in options_text.split('\n') if option.strip()]
    
    if len(options) < 2:
        update.message.reply_text(
            "الرجاء إرسال خيارين على الأقل، كل خيار في سطر منفصل:"
        )
        return OPTIONS
    
    context.user_data['new_question']['options'] = options
    
    # إنشاء أزرار للخيارات
    keyboard = []
    for i, option in enumerate(options):
        keyboard.append([InlineKeyboardButton(f"{chr(65+i)}. {option}", callback_data=f'add_correct_{i}')])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    update.message.reply_text(
        "تم استلام الخيارات.\n\n"
        "الآن، الرجاء اختيار الإجابة الصحيحة:",
        reply_markup=reply_markup
    )
    
    return CORRECT_ANSWER

def add_question_explanation(update: Update, context: CallbackContext) -> int:
    """استلام الإجابة الصحيحة وطلب الشرح."""
    query = update.callback_query
    query.answer()
    
    correct_answer = int(query.data.replace('add_correct_', ''))
    context.user_data['new_question']['correct_answer'] = correct_answer
    
    query.edit_message_text(
        "تم تحديد الإجابة الصحيحة.\n\n"
        "الآن، الرجاء إرسال شرح للإجابة (اختياري، يمكنك إرسال '-' للتخطي):"
    )
    
    return EXPLANATION

def add_question_chapter(update: Update, context: CallbackContext) -> int:
    """استلام الشرح وطلب الفصل."""
    explanation = update.message.text
    
    if explanation != '-':
        context.user_data['new_question']['explanation'] = explanation
    else:
        context.user_data['new_question']['explanation'] = ""
    
    update.message.reply_text(
        "تم استلام الشرح.\n\n"
        "الآن، الرجاء إرسال رقم الفصل (مثال: 1):"
    )
    
    return CHAPTER

def add_question_lesson(update: Update, context: CallbackContext) -> int:
    """استلام الفصل وطلب الدرس."""
    chapter = update.message.text.strip()
    
    if not chapter.isdigit():
        update.message.reply_text(
            "الرجاء إرسال رقم الفصل كرقم فقط (مثال: 1):"
        )
        return CHAPTER
    
    context.user_data['new_question']['chapter'] = chapter
    
    update.message.reply_text(
        "تم استلام رقم الفصل.\n\n"
        "الآن، الرجاء إرسال رقم الدرس (مثال: 2):"
    )
    
    return LESSON

def add_question_finish(update: Update, context: CallbackContext) -> int:
    """استلام الدرس وإضافة السؤال."""
    lesson = update.message.text.strip()
    
    if not lesson.isdigit():
        update.message.reply_text(
            "الرجاء إرسال رقم الدرس كرقم فقط (مثال: 2):"
        )
        return LESSON
    
    context.user_data['new_question']['lesson'] = lesson
    
    # إضافة السؤال إلى قاعدة البيانات
    new_question = context.user_data['new_question']
    QUIZ_DB.add_question(
        new_question['question'],
        new_question['options'],
        new_question['correct_answer'],
        new_question.get('explanation', ""),
        new_question['chapter'],
        new_question['lesson']
    )
    
    # إرسال تأكيد
    keyboard = [
        [InlineKeyboardButton("➕ إضافة سؤال آخر", callback_data='admin_add')],
        [InlineKeyboardButton("🔙 العودة لقائمة الإدارة", callback_data='menu_admin')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    update.message.reply_text(
        "✅ تم إضافة السؤال بنجاح!",
        reply_markup=reply_markup
    )
    
    # مسح بيانات السؤال الجديد
    if 'new_question' in context.user_data:
        del context.user_data['new_question']
    
    return ConversationHandler.END

def add_question_cancel(update: Update, context: CallbackContext) -> int:
    """إلغاء محادثة إضافة السؤال."""
    update.message.reply_text(
        "❌ تم إلغاء إضافة السؤال.",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 العودة لقائمة الإدارة", callback_data='menu_admin')]])
    )
    
    # مسح بيانات السؤال الجديد
    if 'new_question' in context.user_data:
        del context.user_data['new_question']
    
    return ConversationHandler.END

def list_questions(update: Update, context: CallbackContext) -> None:
    """عرض قائمة الأسئلة المخصصة."""
    query = update.callback_query
    
    if not is_admin(update.effective_user.id):
        query.answer("عذراً، هذا القسم متاح للمسؤول فقط.", show_alert=True)
        return
    
    query.answer()
    
    questions = QUIZ_DB.get_all_questions()
    
    if not questions:
        query.edit_message_text(
            "لا توجد أسئلة مخصصة حالياً.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 العودة لقائمة الإدارة", callback_data='menu_admin')]])
        )
        return
    
    # إنشاء قائمة الأسئلة
    message_text = "<b>📋 قائمة الأسئلة المخصصة:</b>\n\n"
    
    for i, question in enumerate(questions):
        # اقتصار طول السؤال للعرض
        short_question = question['question'][:50] + "..." if len(question['question']) > 50 else question['question']
        message_text += f"<b>{i}.</b> {short_question} (الفصل {question['chapter']}, الدرس {question['lesson']})\n"
    
    keyboard = [[InlineKeyboardButton("🔙 العودة لقائمة الإدارة", callback_data='menu_admin')]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    query.edit_message_text(message_text, reply_markup=reply_markup, parse_mode=ParseMode.HTML)

def delete_question_prompt(update: Update, context: CallbackContext) -> None:
    """طلب رقم السؤال المراد حذفه."""
    query = update.callback_query
    
    if not is_admin(update.effective_user.id):
        query.answer("عذراً، هذا القسم متاح للمسؤول فقط.", show_alert=True)
        return
    
    query.answer()
    
    questions = QUIZ_DB.get_all_questions()
    
    if not questions:
        query.edit_message_text(
            "لا توجد أسئلة مخصصة لحذفها.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 العودة لقائمة الإدارة", callback_data='menu_admin')]])
        )
        return
    
    query.edit_message_text(
        "🗑️ حذف سؤال\n\n"
        "الرجاء إرسال رقم السؤال المراد حذفه (كما يظهر في قائمة الأسئلة):"
    )
    
    context.user_data['next_action'] = 'delete_question_index'

def delete_question_confirm(update: Update, context: CallbackContext, index_str: str = None) -> None:
    """تأكيد حذف السؤال."""
    if index_str is None:
        index_str = update.message.text.strip()
    
    if not index_str.isdigit():
        update.message.reply_text(
            "الرجاء إرسال رقم السؤال كرقم فقط:",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 إلغاء", callback_data='menu_admin')]])
        )
        context.user_data['next_action'] = 'delete_question_index'
        return
    
    index = int(index_str)
    questions = QUIZ_DB.get_all_questions()
    
    if index < 0 or index >= len(questions):
        update.message.reply_text(
            f"رقم السؤال غير صحيح. الرجاء إدخال رقم بين 0 و {len(questions)-1}:",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 إلغاء", callback_data='menu_admin')]])
        )
        context.user_data['next_action'] = 'delete_question_index'
        return
    
    question = questions[index]
    
    # عرض السؤال وطلب التأكيد
    message_text = (
        f"<b>هل أنت متأكد من حذف السؤال التالي؟</b>\n\n"
        f"<b>السؤال:</b> {question['question']}\n"
        f"<b>الفصل:</b> {question['chapter']}\n"
        f"<b>الدرس:</b> {question['lesson']}"
    )
    
    keyboard = [
        [InlineKeyboardButton("✅ نعم، احذف السؤال", callback_data=f'confirm_delete_{index}')],
        [InlineKeyboardButton("❌ لا، إلغاء", callback_data='menu_admin')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    update.message.reply_text(message_text, reply_markup=reply_markup, parse_mode=ParseMode.HTML)

def delete_question(update: Update, context: CallbackContext) -> None:
    """حذف السؤال بعد التأكيد."""
    query = update.callback_query
    query.answer()
    
    index = int(query.data.replace('confirm_delete_', ''))
    
    # حذف السؤال
    QUIZ_DB.delete_question(index)
    
    query.edit_message_text(
        "✅ تم حذف السؤال بنجاح!",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 العودة لقائمة الإدارة", callback_data='menu_admin')]])
    )

def show_question_prompt(update: Update, context: CallbackContext) -> None:
    """طلب رقم السؤال المراد عرضه."""
    query = update.callback_query
    
    if not is_admin(update.effective_user.id):
        query.answer("عذراً، هذا القسم متاح للمسؤول فقط.", show_alert=True)
        return
    
    query.answer()
    
    questions = QUIZ_DB.get_all_questions()
    
    if not questions:
        query.edit_message_text(
            "لا توجد أسئلة مخصصة لعرضها.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 العودة لقائمة الإدارة", callback_data='menu_admin')]])
        )
        return
    
    query.edit_message_text(
        "ℹ️ عرض سؤال\n\n"
        "الرجاء إرسال رقم السؤال المراد عرضه (كما يظهر في قائمة الأسئلة):"
    )
    
    context.user_data['next_action'] = 'show_question_index'

def show_question(update: Update, context: CallbackContext, index_str: str = None) -> None:
    """عرض تفاصيل السؤال المحدد."""
    if index_str is None:
        index_str = update.message.text.strip()
    
    if not index_str.isdigit():
        update.message.reply_text(
            "الرجاء إرسال رقم السؤال كرقم فقط:",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 إلغاء", callback_data='menu_admin')]])
        )
        context.user_data['next_action'] = 'show_question_index'
        return
    
    index = int(index_str)
    questions = QUIZ_DB.get_all_questions()
    
    if index < 0 or index >= len(questions):
        update.message.reply_text(
            f"رقم السؤال غير صحيح. الرجاء إدخال رقم بين 0 و {len(questions)-1}:",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 إلغاء", callback_data='menu_admin')]])
        )
        context.user_data['next_action'] = 'show_question_index'
        return
    
    question = questions[index]
    
    # عرض تفاصيل السؤال
    options_text = ""
    for i, option in enumerate(question['options']):
        options_text += f"{'✅ ' if i == question['correct_answer'] else '❌ '}{chr(65+i)}. {option}\n"
    
    message_text = (
        f"<b>📝 تفاصيل السؤال رقم {index}:</b>\n\n"
        f"<b>السؤال:</b> {question['question']}\n\n"
        f"<b>الخيارات:</b>\n{options_text}\n"
        f"<b>الشرح:</b> {question.get('explanation', '')}\n\n"
        f"<b>الفصل:</b> {question['chapter']}\n"
        f"<b>الدرس:</b> {question['lesson']}"
    )
    
    keyboard = [[InlineKeyboardButton("🔙 العودة لقائمة الإدارة", callback_data='menu_admin')]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    update.message.reply_text(message_text, reply_markup=reply_markup, parse_mode=ParseMode.HTML)

# --- دوال استيراد وتصدير الأسئلة ---
def import_questions_prompt(update: Update, context: CallbackContext) -> None:
    """طلب ملف CSV لاستيراد الأسئلة."""
    query = update.callback_query
    
    if not is_admin(update.effective_user.id):
        query.answer("عذراً، هذا القسم متاح للمسؤول فقط.", show_alert=True)
        return
    
    query.answer()
    
    query.edit_message_text(
        "📥 استيراد أسئلة\n\n"
        "الرجاء إرسال ملف CSV يحتوي على الأسئلة المراد استيرادها.\n"
        "يجب أن يكون الملف بالتنسيق التالي:\n"
        "السؤال,الخيار1,الخيار2,الخيار3,الخيار4,رقم الإجابة الصحيحة (0-3),الشرح,الفصل,الدرس\n\n"
        "يمكنك استخدام أمر 'إنشاء قالب' للحصول على ملف قالب.",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 العودة لقائمة الإدارة", callback_data='menu_admin')]])
    )

def handle_import_file(update: Update, context: CallbackContext) -> None:
    """معالجة ملف CSV المستورد."""
    if not is_admin(update.effective_user.id):
        update.message.reply_text("عذراً، هذا القسم متاح للمسؤول فقط.")
        return
    
    # التحقق من وجود ملف
    if not update.message.document:
        update.message.reply_text(
            "الرجاء إرسال ملف CSV.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 العودة لقائمة الإدارة", callback_data='menu_admin')]])
        )
        return
    
    file = update.message.document
    
    # التحقق من نوع الملف
    if not file.file_name.endswith('.csv'):
        update.message.reply_text(
            "الرجاء إرسال ملف بامتداد .csv فقط.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 العودة لقائمة الإدارة", callback_data='menu_admin')]])
        )
        return
    
    # تنزيل الملف
    file_info = context.bot.get_file(file.file_id)
    file_path = os.path.join(os.path.dirname(__file__), file.file_name)
    file_info.download(file_path)
    
    try:
        # استيراد الأسئلة
        count = QUIZ_DB.import_questions_from_csv(file_path)
        
        update.message.reply_text(
            f"✅ تم استيراد {count} سؤال بنجاح!",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 العودة لقائمة الإدارة", callback_data='menu_admin')]])
        )
    except Exception as e:
        update.message.reply_text(
            f"❌ حدث خطأ أثناء استيراد الأسئلة: {str(e)}",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 العودة لقائمة الإدارة", callback_data='menu_admin')]])
        )
    finally:
        # حذف الملف المؤقت
        if os.path.exists(file_path):
            os.remove(file_path)

def export_questions_prompt(update: Update, context: CallbackContext) -> None:
    """تصدير الأسئلة إلى ملف CSV."""
    query = update.callback_query
    
    if not is_admin(update.effective_user.id):
        query.answer("عذراً، هذا القسم متاح للمسؤول فقط.", show_alert=True)
        return
    
    query.answer()
    
    questions = QUIZ_DB.get_all_questions()
    
    if not questions:
        query.edit_message_text(
            "لا توجد أسئلة مخصصة لتصديرها.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 العودة لقائمة الإدارة", callback_data='menu_admin')]])
        )
        return
    
    # تصدير الأسئلة
    file_path = os.path.join(os.path.dirname(__file__), 'exported_questions.csv')
    QUIZ_DB.export_questions_to_csv(file_path)
    
    # إرسال الملف
    with open(file_path, 'rb') as f:
        query.message.reply_document(
            document=f,
            filename='exported_questions.csv',
            caption="📤 تم تصدير الأسئلة بنجاح!"
        )
    
    # حذف الملف المؤقت
    if os.path.exists(file_path):
        os.remove(file_path)
    
    # إرسال رسالة تأكيد
    query.edit_message_text(
        "✅ تم تصدير الأسئلة بنجاح! تم إرسال الملف.",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 العودة لقائمة الإدارة", callback_data='menu_admin')]])
    )

def create_template_prompt(update: Update, context: CallbackContext) -> None:
    """إنشاء ملف قالب CSV للأسئلة."""
    query = update.callback_query
    
    if not is_admin(update.effective_user.id):
        query.answer("عذراً، هذا القسم متاح للمسؤول فقط.", show_alert=True)
        return
    
    query.answer()
    
    # إنشاء ملف قالب
    file_path = os.path.join(os.path.dirname(__file__), 'template.csv')
    QUIZ_DB.create_template_csv(file_path)
    
    # إرسال الملف
    with open(file_path, 'rb') as f:
        query.message.reply_document(
            document=f,
            filename='template.csv',
            caption="📄 تم إنشاء ملف القالب بنجاح!"
        )
    
    # حذف الملف المؤقت
    if os.path.exists(file_path):
        os.remove(file_path)
    
    # إرسال رسالة تأكيد
    query.edit_message_text(
        "✅ تم إنشاء ملف القالب بنجاح! تم إرسال الملف.",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 العودة لقائمة الإدارة", callback_data='menu_admin')]])
    )

def main() -> None:
    """تشغيل البوت."""
    # إنشاء المحدث والحصول على المرسل
    updater = Updater(TOKEN)
    dispatcher = updater.dispatcher
    
    # إضافة معالجات الأوامر
    dispatcher.add_handler(CommandHandler("start", start))
    dispatcher.add_handler(CommandHandler("help", help_command))
    dispatcher.add_handler(CommandHandler("id", id_command))
    
    # إضافة معالج أزرار القوائم
    dispatcher.add_handler(CallbackQueryHandler(main_menu_button_handler, pattern='^(main_menu|menu_|info_|quiz_|admin_)'))
    dispatcher.add_handler(CallbackQueryHandler(handle_quiz_answer, pattern='^quiz_answer_'))
    dispatcher.add_handler(CallbackQueryHandler(handle_quiz_next, pattern='^quiz_next$'))
    dispatcher.add_handler(CallbackQueryHandler(delete_question, pattern='^confirm_delete_'))
    
    # إضافة محادثة إضافة سؤال
    add_question_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(add_question_start, pattern='^admin_add$')],
        states={
            QUESTION: [MessageHandler(Filters.text & ~Filters.command, add_question_options)],
            OPTIONS: [MessageHandler(Filters.text & ~Filters.command, add_question_correct_answer)],
            CORRECT_ANSWER: [CallbackQueryHandler(add_question_explanation, pattern='^add_correct_')],
            EXPLANATION: [MessageHandler(Filters.text & ~Filters.command, add_question_chapter)],
            CHAPTER: [MessageHandler(Filters.text & ~Filters.command, add_question_lesson)],
            LESSON: [MessageHandler(Filters.text & ~Filters.command, add_question_finish)],
        },
        fallbacks=[CommandHandler("cancel", add_question_cancel)],
    )
    dispatcher.add_handler(add_question_conv)
    
    # إضافة معالج الرسائل النصية
    dispatcher.add_handler(MessageHandler(Filters.text & ~Filters.command, handle_text_input))
    
    # إضافة معالج ملفات CSV
    dispatcher.add_handler(MessageHandler(Filters.document, handle_import_file))
    
    # بدء البوت
    updater.start_polling()
    updater.idle()

if __name__ == '__main__':
    main()
