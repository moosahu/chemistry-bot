#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import logging
import random
import os
import time
import sys
import base64
from io import BytesIO
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, InputMediaPhoto
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes, CallbackQueryHandler, ConversationHandler
from telegram.constants import ParseMode
from telegram.error import NetworkError, TelegramError
from chemistry_data import ELEMENTS, COMPOUNDS, CONCEPTS, QUIZ_QUESTIONS, PERIODIC_TABLE_INFO, CHEMICAL_CALCULATIONS_INFO, CHEMICAL_BONDS_INFO
from quiz_db import QuizDatabase
from chemical_equations import process_text_with_chemical_notation, format_chemical_equation

# --- إعدادات --- 
# ضع معرف المستخدم الرقمي الخاص بك هنا لتقييد الوصول إلى إدارة قاعدة البيانات
ADMIN_USER_ID = 6448526509 # استبدل None بمعرف المستخدم الرقمي الخاص بك (مثال: 123456789)
# تكوين التسجيل
log_file_path = os.path.join(os.path.dirname(__file__), 'bot_log.txt')
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO,
    handlers=[
        logging.FileHandler(log_file_path, encoding='utf-8'), # تسجيل في ملف فقط
        # logging.StreamHandler(sys.stdout) # تم التعليق لتجنب الازدواجية عند استخدام nohup
    ]
)
logger = logging.getLogger(__name__)

# تهيئة قاعدة بيانات الأسئلة
QUIZ_DB = QuizDatabase(os.path.join(os.path.dirname(__file__), 'questions.json'))

# حالات المحادثة لإضافة سؤال وحذف/عرض سؤال
(QUESTION, OPTIONS, CORRECT_ANSWER, EXPLANATION, CHAPTER, LESSON, 
 DELETE_CONFIRM, SHOW_INDEX) = range(8)

# --- وظائف التحقق من الصلاحيات ---
def is_admin(user_id: int) -> bool:
    """التحقق مما إذا كان المستخدم هو المسؤول."""
    if ADMIN_USER_ID is None:
        logger.warning("ADMIN_USER_ID غير معين. سيتم السماح للجميع بإدارة قاعدة البيانات.")
        return True # السماح للجميع إذا لم يتم تعيين المسؤول
    return user_id == ADMIN_USER_ID

# --- الدوال المساعدة للقوائم ---
async def show_main_menu(update: Update, context: ContextTypes.DEFAULT_TYPE, message_text: str = None) -> None:
    """عرض القائمة الرئيسية مع الأزرار."""
    keyboard = [
        [InlineKeyboardButton("📚 المعلومات الكيميائية", callback_data='menu_info')],
        [InlineKeyboardButton("📝 الاختبارات", callback_data='menu_quiz')],
        [InlineKeyboardButton("ℹ️ حول البوت", callback_data='menu_about')],
    ]
    if is_admin(update.effective_user.id):
        keyboard.append([InlineKeyboardButton("⚙️ إدارة الأسئلة", callback_data='menu_admin')])

    reply_markup = InlineKeyboardMarkup(keyboard)

    if message_text is None:
        user = update.effective_user
        message_text = (
            f"مرحباً بك في بوت الكيمياء التحصيلي 🧪\n\n"
            f"أهلاً {user.first_name}! 👋\n\n"
            f"اختر أحد الخيارات أدناه:"
        )

    # إذا كان التحديث من callback_query، استخدم edit_message_text
    if update.callback_query:
        try:
            await update.callback_query.edit_message_text(message_text, reply_markup=reply_markup, parse_mode=ParseMode.HTML)
        except TelegramError as e:
            # تجاهل الخطأ إذا كانت الرسالة لم تتغير
            if "Message is not modified" not in str(e):
                logger.error(f"Error editing message: {e}")
                # محاولة إرسال رسالة جديدة كحل بديل
                await update.effective_message.reply_text(message_text, reply_markup=reply_markup, parse_mode=ParseMode.HTML)
    # إذا كان التحديث من رسالة (مثل /start)، استخدم reply_text
    elif update.message:
        await update.message.reply_text(message_text, reply_markup=reply_markup, parse_mode=ParseMode.HTML)

async def show_info_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """عرض قائمة المعلومات الكيميائية."""
    keyboard = [
        [InlineKeyboardButton("عنصر كيميائي", callback_data='info_element_prompt')],
        [InlineKeyboardButton("مركب كيميائي", callback_data='info_compound_prompt')],
        [InlineKeyboardButton("مفهوم كيميائي", callback_data='info_concept_prompt')],
        [InlineKeyboardButton("الجدول الدوري", callback_data='info_periodic')],
        [InlineKeyboardButton("الحسابات الكيميائية", callback_data='info_calculations')],
        [InlineKeyboardButton("الروابط الكيميائية", callback_data='info_bonds')],
        [InlineKeyboardButton("🔙 العودة للقائمة الرئيسية", callback_data='main_menu')],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.callback_query.edit_message_text("📚 اختر نوع المعلومات الكيميائية:", reply_markup=reply_markup)

async def show_quiz_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """عرض قائمة الاختبارات."""
    keyboard = [
        [InlineKeyboardButton("اختبار تحصيلي عام (مخصص)", callback_data='quiz_tahseely')],
        [InlineKeyboardButton("اختبار حسب الفصل (مخصص)", callback_data='quiz_chapter_select')],
        [InlineKeyboardButton("اختبار حسب الدرس (مخصص)", callback_data='quiz_lesson_select_chapter')],
        [InlineKeyboardButton("اختبار قصير (مضمن)", callback_data='quiz_builtin')],
        [InlineKeyboardButton("🔙 العودة للقائمة الرئيسية", callback_data='main_menu')],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.callback_query.edit_message_text("📝 اختر نوع الاختبار:", reply_markup=reply_markup)

async def show_admin_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """عرض قائمة إدارة الأسئلة للمسؤول."""
    if not is_admin(update.effective_user.id):
        await update.callback_query.answer("عذراً، هذا القسم متاح للمسؤول فقط.", show_alert=True)
        return

    keyboard = [
        [InlineKeyboardButton("➕ إضافة سؤال جديد", callback_data='admin_add')],
        [InlineKeyboardButton("📥 استيراد أسئلة", callback_data='admin_import_questions')],
        [InlineKeyboardButton("📤 تصدير أسئلة", callback_data='admin_export_questions')],
        [InlineKeyboardButton("📄 إنشاء قالب", callback_data='admin_create_template')],
        [InlineKeyboardButton("📋 عرض قائمة الأسئلة", callback_data='admin_list')],
        [InlineKeyboardButton("🗑️ حذف سؤال", callback_data='admin_delete_prompt')],
        [InlineKeyboardButton("ℹ️ عرض سؤال معين", callback_data='admin_show_prompt')],
        [InlineKeyboardButton("🔙 العودة للقائمة الرئيسية", callback_data='main_menu')],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.callback_query.edit_message_text("⚙️ اختر عملية إدارة الأسئلة:", reply_markup=reply_markup)

# --- الدوال المساعدة الأساسية (معدلة للقوائم) ---
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """إرسال رسالة عند تنفيذ أمر /start وعرض القائمة الرئيسية."""
    await show_main_menu(update, context)

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """عرض القائمة الرئيسية عند تنفيذ أمر /help."""
    await show_main_menu(update, context, message_text="القائمة الرئيسية 👇")

async def about_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """إرسال معلومات عن البوت عند الضغط على زر 'حول البوت'."""
    about_text = (
        "<b>بوت كيمياء تحصيلي 🧪</b>\n\n"
        "هذا البوت مصمم لمساعدة الطلاب في دراسة الكيمياء والتحضير للاختبارات التحصيلية.\n"
        "<b>تحت إشراف الأستاذ حسين الموسى</b>\n\n"
        "<b>يمكن للبوت تقديم:</b>\n"
        "• معلومات عن العناصر والمركبات الكيميائية\n"
        "• شرح للمفاهيم الأساسية في الكيمياء\n"
        "• اختبارات تجريبية متنوعة (مضمنة ومخصصة حسب الفصل والدرس)\n"
        "• معلومات عن الجدول الدوري\n"
        "• مساعدة في الحسابات الكيميائية\n"
        "• شرح أنواع الروابط الكيميائية\n"
        "• إمكانية إضافة أسئلة اختبارية مخصصة (للمسؤول فقط)\n\n"
        "استخدم الأزرار للتنقل بين الخيارات." 
    )
    keyboard = [[InlineKeyboardButton("🔙 العودة للقائمة الرئيسية", callback_data='main_menu')]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    # التحقق إذا كان التحديث من callback_query أو message
    if update.callback_query:
        await update.callback_query.edit_message_text(about_text, reply_markup=reply_markup, parse_mode=ParseMode.HTML)
    elif update.message: # في حال استدعاء /about مباشرة (غير مرجح مع الأزرار)
         await update.message.reply_text(about_text, reply_markup=reply_markup, parse_mode=ParseMode.HTML)

async def id_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """إرسال معرف المستخدم عند تنفيذ أمر /id."""
    user_id = update.effective_user.id
    await update.message.reply_text(f"معرف المستخدم الخاص بك هو: {user_id}")

# --- معالجات أزرار القوائم الرئيسية ---
async def main_menu_button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """معالجة الضغط على أزرار القائمة الرئيسية وقوائم فرعية أخرى."""
    query = update.callback_query
    await query.answer()
    data = query.data

    if data == 'main_menu':
        await show_main_menu(update, context, message_text="القائمة الرئيسية 👇")
    elif data == 'menu_info':
        await show_info_menu(update, context)
    elif data == 'menu_quiz':
        await show_quiz_menu(update, context)
    elif data == 'menu_about':
        await about_command(update, context)
    elif data == 'menu_admin':
        await show_admin_menu(update, context)
    # --- معالجات أزرار قائمة المعلومات ---
    elif data == 'info_element_prompt':
        await query.message.reply_text("الرجاء إرسال اسم العنصر الذي تريد البحث عنه (مثال: هيدروجين)")
        context.user_data['next_action'] = 'search_element'
    elif data == 'info_compound_prompt':
        await query.message.reply_text("الرجاء إرسال اسم المركب الذي تريد البحث عنه (مثال: ماء)")
        context.user_data['next_action'] = 'search_compound'
    elif data == 'info_concept_prompt':
        await query.message.reply_text("الرجاء إرسال اسم المفهوم الذي تريد البحث عنه (مثال: الذرة)")
        context.user_data['next_action'] = 'search_concept'
    elif data == 'info_periodic':
        await periodic_table_command(update, context)
    elif data == 'info_calculations':
        await calculations_command(update, context)
    elif data == 'info_bonds':
        await bonds_command(update, context)
    # --- معالجات أزرار قائمة الاختبارات ---
    elif data == 'quiz_builtin':
        await quiz_command(update, context)
    elif data == 'quiz_tahseely':
        await custom_quiz_start(update, context, quiz_type='all')
    elif data == 'quiz_chapter_select':
        await custom_quiz_select_chapter(update, context)
    elif data == 'quiz_lesson_select_chapter':
        await custom_quiz_select_lesson_chapter(update, context)
    elif data.startswith('quiz_select_chapter_'):
        chapter = data.replace('quiz_select_chapter_', '')
        await custom_quiz_start(update, context, quiz_type='chapter', category=chapter)
    elif data.startswith('quiz_select_lesson_chapter_'):
        chapter = data.replace('quiz_select_lesson_chapter_', '')
        await custom_quiz_select_lesson(update, context, chapter)
    elif data.startswith('quiz_select_lesson_'):
        parts = data.replace('quiz_select_lesson_', '').split('|', 1)
        chapter = parts[0]
        lesson = parts[1]
        await custom_quiz_start(update, context, quiz_type='lesson', category=lesson, chapter=chapter)
    # --- معالجات أزرار قائمة الإدارة ---
    elif data == 'admin_add':
        # بدء محادثة إضافة السؤال
        await add_question_start(update, context)
    elif data == 'admin_list':
        await list_questions(update, context)
    elif data == 'admin_delete_prompt':
        # بدء محادثة حذف السؤال
        await delete_question_prompt(update, context)
    elif data == 'admin_show_prompt':
        # بدء محادثة عرض السؤال
        await show_question_prompt(update, context)
    elif data == 'admin_import_questions':
        # بدء محادثة استيراد الأسئلة
        await import_questions_prompt(update, context)
    elif data == 'admin_export_questions':
        # بدء محادثة تصدير الأسئلة
        await export_questions_prompt(update, context)
    elif data == 'admin_create_template':
        # بدء محادثة إنشاء قالب
        await create_template_prompt(update, context)

async def handle_text_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """معالجة إدخال النص بعد طلب البحث عن عنصر/مركب/مفهوم."""
    # تجاهل إذا كانت الرسالة من محادثة نشطة (مثل إضافة سؤال)
    if ConversationHandler.check_update(update):
        return
        
    if 'next_action' in context.user_data:
        action = context.user_data.pop('next_action')
        text = update.message.text
        # إعادة استخدام الدوال الموجودة مع تعديل بسيط
        if action == 'search_element':
            await element_command(update, context, element_name=text)
        elif action == 'search_compound':
            await compound_command(update, context, compound_name=text)
        elif action == 'search_concept':
            await concept_command(update, context, concept_name=text)
        elif action == 'delete_question_index':
             await delete_question_confirm(update, context, index_str=text)
        elif action == 'show_question_index':
             await show_question(update, context, index_str=text)
    else:
        # التعامل مع الرسائل النصية العادية الأخرى إذا لزم الأمر
        # await update.message.reply_text("لم أفهم طلبك. استخدم الأزرار أو الأوامر المتاحة.")
        pass # تجاهل الرسائل النصية غير المتوقعة

# --- دوال المعلومات الكيميائية (معدلة لاستقبال الاسم مباشرة وعرض زر العودة) ---
async def element_command(update: Update, context: ContextTypes.DEFAULT_TYPE, element_name: str = None) -> None:
    """إرسال معلومات عن عنصر كيميائي."""
    message = update.effective_message # استخدام الرسالة الفعالة (قد تكون من callback query)
    if element_name is None: # إذا تم استدعاؤه كأمر نصي
        if not context.args:
            await message.reply_text(
                "الرجاء إدخال اسم العنصر بعد الأمر. مثال: /element هيدروجين"
            )
            return
        element_name = " ".join(context.args)

    if element_name in ELEMENTS:
        element = ELEMENTS[element_name]
        response = (
            f"<b>🔍 معلومات عن عنصر {element_name}:</b>\n\n"
            f"<b>الرمز:</b> {element['رمز']}\n"
            f"<b>الرقم الذري:</b> {element['رقم_ذري']}\n"
            f"<b>الوزن الذري:</b> {element['وزن_ذري']} وحدة كتل ذرية"
        )
    else:
        response = f"عذراً، لم أجد معلومات عن العنصر '{element_name}'. تأكد من كتابة اسم العنصر بشكل صحيح."
    
    keyboard = [[InlineKeyboardButton("🔙 العودة لقائمة المعلومات", callback_data='menu_info')]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await message.reply_text(response, reply_markup=reply_markup, parse_mode=ParseMode.HTML)

async def compound_command(update: Update, context: ContextTypes.DEFAULT_TYPE, compound_name: str = None) -> None:
    """إرسال معلومات عن مركب كيميائي."""
    message = update.effective_message
    if compound_name is None:
        if not context.args:
            await message.reply_text(
                "الرجاء إدخال اسم المركب بعد الأمر. مثال: /compound ماء"
            )
            return
        compound_name = " ".join(context.args)

    if compound_name in COMPOUNDS:
        compound = COMPOUNDS[compound_name]
        response = (
            f"<b>🧪 معلومات عن مركب {compound_name}:</b>\n\n"
            f"<b>الصيغة الكيميائية:</b> {compound['صيغة']}\n"
            f"<b>النوع:</b> {compound['نوع']}\n"
            f"<b>الحالة الفيزيائية:</b> {compound['حالة']}"
        )
    else:
        response = f"عذراً، لم أجد معلومات عن المركب '{compound_name}'. تأكد من كتابة اسم المركب بشكل صحيح."
    
    keyboard = [[InlineKeyboardButton("🔙 العودة لقائمة المعلومات", callback_data='menu_info')]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await message.reply_text(response, reply_markup=reply_markup, parse_mode=ParseMode.HTML)

async def concept_command(update: Update, context: ContextTypes.DEFAULT_TYPE, concept_name: str = None) -> None:
    """إرسال شرح لمفهوم كيميائي."""
    message = update.effective_message
    if concept_name is None:
        if not context.args:
            await message.reply_text(
                "الرجاء إدخال اسم المفهوم بعد الأمر. مثال: /concept الذرة"
            )
            return
        concept_name = " ".join(context.args)

    if concept_name in CONCEPTS:
        response = f"<b>📚 {concept_name}:</b>\n\n{CONCEPTS[concept_name]}"
    else:
        response = f"عذراً، لم أجد شرحاً للمفهوم '{concept_name}'. تأكد من كتابة اسم المفهوم بشكل صحيح."
    
    keyboard = [[InlineKeyboardButton("🔙 العودة لقائمة المعلومات", callback_data='menu_info')]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await message.reply_text(response, reply_markup=reply_markup, parse_mode=ParseMode.HTML)

async def periodic_table_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """إرسال معلومات عن الجدول الدوري."""
    message = update.effective_message
    keyboard = [[InlineKeyboardButton("🔙 العودة لقائمة المعلومات", callback_data='menu_info')]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await message.reply_text(PERIODIC_TABLE_INFO, reply_markup=reply_markup, parse_mode=ParseMode.HTML)

async def calculations_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """إرسال معلومات عن الحسابات الكيميائية."""
    message = update.effective_message
    keyboard = [[InlineKeyboardButton("🔙 العودة لقائمة المعلومات", callback_data='menu_info')]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await message.reply_text(CHEMICAL_CALCULATIONS_INFO, reply_markup=reply_markup, parse_mode=ParseMode.HTML)

async def bonds_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """إرسال معلومات عن الروابط الكيميائية."""
    message = update.effective_message
    keyboard = [[InlineKeyboardButton("🔙 العودة لقائمة المعلومات", callback_data='menu_info')]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await message.reply_text(CHEMICAL_BONDS_INFO, reply_markup=reply_markup, parse_mode=ParseMode.HTML)

# --- دوال الاختبار المضمن (/quiz) (معدلة للأزرار) ---
async def quiz_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """بدء اختبار قصير في الكيمياء (من الأسئلة المضمنة)."""
    message = update.effective_message
    question_data = random.choice(QUIZ_QUESTIONS)
    question = question_data["سؤال"]
    options = question_data["خيارات"]
    correct_option_index = options.index(question_data['إجابة_صحيحة'])
    explanation = question_data['شرح']
    
    keyboard = []
    for i, option in enumerate(options):
        # تخزين الإجابة الصحيحة والشرح في بيانات الاستدعاء
        callback_data = f"builtin_quiz_{i}_{correct_option_index}_{explanation[:30]}" # تحديد طول الشرح لتجنب تجاوز الحد
        keyboard.append([InlineKeyboardButton(option, callback_data=callback_data)])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    # إرسال السؤال النصي
    await message.reply_text(
        f"📝 سؤال (مضمن): {question}",
        reply_markup=reply_markup
    )
    
    # إرسال صورة السؤال إذا كانت موجودة
    if 'صورة_السؤال' in question_data and question_data['صورة_السؤال']:
        try:
            image_data = base64.b64decode(question_data['صورة_السؤال'])
            photo = BytesIO(image_data)
            photo.name = 'question_image.jpg'
            await message.reply_photo(photo=photo, caption="صورة السؤال")
        except Exception as e:
            logger.error(f"خطأ في عرض صورة السؤال: {e}")

async def builtin_quiz_button(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """معالجة الضغط على أزرار الاختبار المضمن."""
    query = update.callback_query
    await query.answer()
    
    data = query.data.split("_")
    prefix = data[0] # builtin
    selected_option_index = int(data[2])
    correct_option_index = int(data[3])
    # explanation_part = data[4] # لا نحتاج لاستعادة الشرح من هنا

    # العثور على السؤال الأصلي بناءً على الإجابة الصحيحة (طريقة أفضل)
    original_question_data = None
    for q in QUIZ_QUESTIONS:
        try:
            if q['خيارات'][correct_option_index] == q['إجابة_صحيحة']:
                # تحقق إضافي للتأكد من أنه نفس السؤال تقريبًا
                if q['خيارات'][selected_option_index] in [btn.text for row in query.message.reply_markup.inline_keyboard for btn in row]:
                    original_question_data = q
                    break
        except IndexError:
            continue # تجاهل الأسئلة ذات التنسيق غير الصحيح
    
    if original_question_data:
        explanation = original_question_data['شرح']
    else:
        explanation = "لم يتم العثور على شرح للإجابة."
    
    # تحديد ما إذا كانت الإجابة صحيحة أم خاطئة
    is_correct = selected_option_index == correct_option_index
    
    # إنشاء رسالة الرد
    if is_correct:
        result_text = "✅ إجابة صحيحة!\n\n"
    else:
        result_text = f"❌ إجابة خاطئة. الإجابة الصحيحة هي: {query.message.reply_markup.inline_keyboard[correct_option_index][0].text}\n\n"
    
    result_text += f"<b>الشرح:</b>\n{explanation}"
    
    # إضافة أزرار للاستمرار
    keyboard = [
        [InlineKeyboardButton("🔄 سؤال آخر", callback_data='quiz_builtin')],
        [InlineKeyboardButton("🔙 العودة لقائمة الاختبارات", callback_data='menu_quiz')],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    # تحديث الرسالة الأصلية
    await query.edit_message_text(result_text, reply_markup=reply_markup, parse_mode=ParseMode.HTML)

# --- دوال الاختبار المخصص (حسب الفصل والدرس) ---
async def custom_quiz_select_chapter(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """عرض قائمة الفصول للاختيار."""
    # الحصول على قائمة الفصول المتاحة
    chapters = set(q['الفصل'] for q in QUIZ_DB.questions if 'الفصل' in q)
    
    if not chapters:
        await update.callback_query.edit_message_text(
            "لا توجد أسئلة مخصصة متاحة حالياً. يرجى إضافة أسئلة أولاً.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 العودة", callback_data='menu_quiz')]])
        )
        return
    
    # إنشاء أزرار للفصول
    keyboard = []
    for chapter in sorted(chapters):
        keyboard.append([InlineKeyboardButton(chapter, callback_data=f'quiz_select_chapter_{chapter}')])
    
    keyboard.append([InlineKeyboardButton("🔙 العودة لقائمة الاختبارات", callback_data='menu_quiz')])
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text("اختر الفصل للاختبار:", reply_markup=reply_markup)

async def custom_quiz_select_lesson_chapter(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """عرض قائمة الفصول لاختيار الدرس."""
    # الحصول على قائمة الفصول المتاحة
    chapters = set(q['الفصل'] for q in QUIZ_DB.questions if 'الفصل' in q)
    
    if not chapters:
        await update.callback_query.edit_message_text(
            "لا توجد أسئلة مخصصة متاحة حالياً. يرجى إضافة أسئلة أولاً.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 العودة", callback_data='menu_quiz')]])
        )
        return
    
    # إنشاء أزرار للفصول
    keyboard = []
    for chapter in sorted(chapters):
        keyboard.append([InlineKeyboardButton(chapter, callback_data=f'quiz_select_lesson_chapter_{chapter}')])
    
    keyboard.append([InlineKeyboardButton("🔙 العودة لقائمة الاختبارات", callback_data='menu_quiz')])
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text("اختر الفصل أولاً:", reply_markup=reply_markup)

async def custom_quiz_select_lesson(update: Update, context: ContextTypes.DEFAULT_TYPE, chapter: str) -> None:
    """عرض قائمة الدروس للفصل المحدد."""
    # الحصول على قائمة الدروس المتاحة للفصل المحدد
    lessons = set(q['الدرس'] for q in QUIZ_DB.questions if 'الفصل' in q and q['الفصل'] == chapter and 'الدرس' in q)
    
    if not lessons:
        await update.callback_query.edit_message_text(
            f"لا توجد دروس متاحة للفصل '{chapter}'. يرجى إضافة أسئلة لهذا الفصل أولاً.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 العودة", callback_data='quiz_lesson_select_chapter')]])
        )
        return
    
    # إنشاء أزرار للدروس
    keyboard = []
    for lesson in sorted(lessons):
        keyboard.append([InlineKeyboardButton(lesson, callback_data=f'quiz_select_lesson_{chapter}|{lesson}')])
    
    keyboard.append([InlineKeyboardButton("🔙 العودة لاختيار الفصل", callback_data='quiz_lesson_select_chapter')])
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(f"اختر الدرس من {chapter}:", reply_markup=reply_markup)

async def custom_quiz_start(update: Update, context: ContextTypes.DEFAULT_TYPE, quiz_type: str = 'all', category: str = None, chapter: str = None) -> None:
    """بدء اختبار مخصص (جميع الأسئلة، حسب الفصل، أو حسب الدرس)."""
    # تصفية الأسئلة حسب النوع
    filtered_questions = []
    
    if quiz_type == 'all':
        filtered_questions = QUIZ_DB.questions
        quiz_title = "اختبار تحصيلي عام"
    elif quiz_type == 'chapter':
        filtered_questions = [q for q in QUIZ_DB.questions if 'الفصل' in q and q['الفصل'] == category]
        quiz_title = f"اختبار {category}"
    elif quiz_type == 'lesson':
        filtered_questions = [q for q in QUIZ_DB.questions if 'الفصل' in q and q['الفصل'] == chapter and 'الدرس' in q and q['الدرس'] == category]
        quiz_title = f"اختبار {category} ({chapter})"
    
    if not filtered_questions:
        await update.callback_query.edit_message_text(
            "لا توجد أسئلة متاحة لهذا الاختيار. يرجى إضافة أسئلة أولاً.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 العودة", callback_data='menu_quiz')]])
        )
        return
    
    # اختيار سؤال عشوائي
    question_data = random.choice(filtered_questions)
    question = question_data["سؤال"]
    options = question_data["خيارات"]
    correct_answer = question_data["إجابة_صحيحة"]
    correct_option_index = options.index(correct_answer)
    explanation = question_data['شرح']
    
    # معالجة المعادلات الكيميائية في السؤال والخيارات
    question = process_text_with_chemical_notation(question)
    options = [process_text_with_chemical_notation(option) for option in options]
    explanation = process_text_with_chemical_notation(explanation)
    
    # إنشاء أزرار للخيارات
    keyboard = []
    for i, option in enumerate(options):
        # تخزين معلومات السؤال في بيانات الاستدعاء
        callback_data = f"custom_quiz_{quiz_type}_{i}_{correct_option_index}"
        if quiz_type == 'chapter' and category:
            callback_data += f"_{category}"
        elif quiz_type == 'lesson' and category and chapter:
            callback_data += f"_{chapter}|{category}"
        
        keyboard.append([InlineKeyboardButton(option, callback_data=callback_data)])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    # إرسال السؤال النصي
    await update.callback_query.edit_message_text(
        f"📝 {quiz_title}: {question}",
        reply_markup=reply_markup,
        parse_mode=ParseMode.HTML
    )
    
    # إرسال صورة السؤال إذا كانت موجودة
    if 'صورة_السؤال' in question_data and question_data['صورة_السؤال']:
        try:
            image_data = base64.b64decode(question_data['صورة_السؤال'])
            photo = BytesIO(image_data)
            photo.name = 'question_image.jpg'
            await update.effective_message.reply_photo(photo=photo, caption="صورة السؤال")
        except Exception as e:
            logger.error(f"خطأ في عرض صورة السؤال: {e}")

async def custom_quiz_button(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """معالجة الضغط على أزرار الاختبار المخصص."""
    query = update.callback_query
    await query.answer()
    
    data = query.data.split("_")
    prefix = data[0] # custom
    quiz_type = data[2] # all, chapter, lesson
    selected_option_index = int(data[3])
    correct_option_index = int(data[4])
    
    # استعادة معلومات التصفية
    category = None
    chapter = None
    if len(data) > 5:
        if quiz_type == 'chapter':
            category = data[5]
        elif quiz_type == 'lesson':
            parts = data[5].split('|', 1)
            chapter = parts[0]
            category = parts[1]
    
    # تصفية الأسئلة للعثور على السؤال الأصلي
    filtered_questions = []
    if quiz_type == 'all':
        filtered_questions = QUIZ_DB.questions
    elif quiz_type == 'chapter':
        filtered_questions = [q for q in QUIZ_DB.questions if 'الفصل' in q and q['الفصل'] == category]
    elif quiz_type == 'lesson':
        filtered_questions = [q for q in QUIZ_DB.questions if 'الفصل' in q and q['الفصل'] == chapter and 'الدرس' in q and q['الدرس'] == category]
    
    # العثور على السؤال الأصلي
    original_question_data = None
    for q in filtered_questions:
        try:
            if q['خيارات'][correct_option_index] == q['إجابة_صحيحة']:
                # تحقق إضافي للتأكد من أنه نفس السؤال تقريبًا
                processed_option = process_text_with_chemical_notation(q['خيارات'][selected_option_index])
                if processed_option in [btn.text for row in query.message.reply_markup.inline_keyboard for btn in row]:
                    original_question_data = q
                    break
        except (IndexError, KeyError):
            continue # تجاهل الأسئلة ذات التنسيق غير الصحيح
    
    if original_question_data:
        explanation = process_text_with_chemical_notation(original_question_data['شرح'])
    else:
        explanation = "لم يتم العثور على شرح للإجابة."
    
    # تحديد ما إذا كانت الإجابة صحيحة أم خاطئة
    is_correct = selected_option_index == correct_option_index
    
    # إنشاء رسالة الرد
    if is_correct:
        result_text = "✅ إجابة صحيحة!\n\n"
    else:
        result_text = f"❌ إجابة خاطئة. الإجابة الصحيحة هي: {query.message.reply_markup.inline_keyboard[correct_option_index][0].text}\n\n"
    
    result_text += f"<b>الشرح:</b>\n{explanation}"
    
    # إضافة أزرار للاستمرار
    keyboard = []
    
    # زر لسؤال آخر من نفس النوع
    if quiz_type == 'all':
        keyboard.append([InlineKeyboardButton("🔄 سؤال آخر", callback_data='quiz_tahseely')])
    elif quiz_type == 'chapter':
        keyboard.append([InlineKeyboardButton("🔄 سؤال آخر", callback_data=f'quiz_select_chapter_{category}')])
    elif quiz_type == 'lesson':
        keyboard.append([InlineKeyboardButton("🔄 سؤال آخر", callback_data=f'quiz_select_lesson_{chapter}|{category}')])
    
    keyboard.append([InlineKeyboardButton("🔙 العودة لقائمة الاختبارات", callback_data='menu_quiz')])
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    # تحديث الرسالة الأصلية
    await query.edit_message_text(result_text, reply_markup=reply_markup, parse_mode=ParseMode.HTML)

# --- دوال إدارة الأسئلة ---
async def add_question_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """بدء محادثة إضافة سؤال جديد."""
    if not is_admin(update.effective_user.id):
        await update.callback_query.answer("عذراً، هذا القسم متاح للمسؤول فقط.", show_alert=True)
        return ConversationHandler.END
    
    await update.callback_query.edit_message_text(
        "لنبدأ بإضافة سؤال جديد إلى قاعدة البيانات.\n\n"
        "الخطوة 1/6: الرجاء إدخال نص السؤال:\n\n"
        "(لإلغاء العملية، أرسل /cancel)"
    )
    
    return QUESTION

async def add_question_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """معالجة نص السؤال المدخل."""
    context.user_data['question'] = update.message.text
    
    await update.message.reply_text(
        "الخطوة 2/6: الرجاء إدخال الخيارات الأربعة، كل خيار في رسالة منفصلة.\n\n"
        "أدخل الخيار الأول:"
    )
    
    context.user_data['options'] = []
    return OPTIONS

async def add_question_options(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """معالجة خيارات السؤال المدخلة."""
    context.user_data['options'].append(update.message.text)
    
    if len(context.user_data['options']) < 4:
        await update.message.reply_text(f"أدخل الخيار {len(context.user_data['options']) + 1}:")
        return OPTIONS
    
    # عرض الخيارات للمستخدم
    options_text = "\n".join([f"{i+1}. {option}" for i, option in enumerate(context.user_data['options'])])
    
    await update.message.reply_text(
        f"الخطوة 3/6: الرجاء اختيار الإجابة الصحيحة من الخيارات التالية:\n\n"
        f"{options_text}\n\n"
        f"أدخل رقم الإجابة الصحيحة (1-4):"
    )
    
    return CORRECT_ANSWER

async def add_question_correct_answer(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """معالجة الإجابة الصحيحة المدخلة."""
    try:
        answer_index = int(update.message.text) - 1
        if answer_index < 0 or answer_index >= len(context.user_data['options']):
            await update.message.reply_text(
                "رقم غير صالح. الرجاء إدخال رقم بين 1 و 4:"
            )
            return CORRECT_ANSWER
        
        context.user_data['correct_answer'] = context.user_data['options'][answer_index]
        
        await update.message.reply_text(
            "الخطوة 4/6: الرجاء إدخال شرح للإجابة الصحيحة:"
        )
        
        return EXPLANATION
    
    except ValueError:
        await update.message.reply_text(
            "إدخال غير صالح. الرجاء إدخال رقم بين 1 و 4:"
        )
        return CORRECT_ANSWER

async def add_question_explanation(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """معالجة شرح الإجابة المدخل."""
    context.user_data['explanation'] = update.message.text
    
    await update.message.reply_text(
        "الخطوة 5/6: الرجاء إدخال اسم الفصل:"
    )
    
    return CHAPTER

async def add_question_chapter(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """معالجة اسم الفصل المدخل."""
    context.user_data['chapter'] = update.message.text
    
    await update.message.reply_text(
        "الخطوة 6/6: الرجاء إدخال اسم الدرس:"
    )
    
    return LESSON

async def add_question_lesson(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """معالجة اسم الدرس المدخل وإضافة السؤال."""
    context.user_data['lesson'] = update.message.text
    
    # إضافة السؤال إلى قاعدة البيانات
    success = QUIZ_DB.add_question(
        context.user_data['question'],
        context.user_data['options'],
        context.user_data['correct_answer'],
        context.user_data['explanation'],
        context.user_data['chapter'],
        context.user_data['lesson']
    )
    
    if success:
        await update.message.reply_text(
            "✅ تمت إضافة السؤال بنجاح إلى قاعدة البيانات!"
        )
    else:
        await update.message.reply_text(
            "❌ حدث خطأ أثناء إضافة السؤال. يرجى المحاولة مرة أخرى."
        )
    
    # إظهار قائمة الإدارة مرة أخرى
    keyboard = [
        [InlineKeyboardButton("➕ إضافة سؤال آخر", callback_data='admin_add')],
        [InlineKeyboardButton("🔙 العودة لقائمة الإدارة", callback_data='menu_admin')],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        "ماذا تريد أن تفعل الآن؟",
        reply_markup=reply_markup
    )
    
    return ConversationHandler.END

async def add_question_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """إلغاء محادثة إضافة السؤال."""
    await update.message.reply_text(
        "تم إلغاء عملية إضافة السؤال."
    )
    
    # إظهار قائمة الإدارة مرة أخرى
    keyboard = [[InlineKeyboardButton("🔙 العودة لقائمة الإدارة", callback_data='menu_admin')]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        "ماذا تريد أن تفعل الآن؟",
        reply_markup=reply_markup
    )
    
    return ConversationHandler.END

async def list_questions(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """عرض قائمة بجميع الأسئلة المخصصة."""
    if not is_admin(update.effective_user.id):
        await update.callback_query.answer("عذراً، هذا القسم متاح للمسؤول فقط.", show_alert=True)
        return
    
    if not QUIZ_DB.questions:
        await update.callback_query.edit_message_text(
            "لا توجد أسئلة في قاعدة البيانات حالياً.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 العودة", callback_data='menu_admin')]])
        )
        return
    
    # تجميع الأسئلة حسب الفصل والدرس
    questions_by_chapter = {}
    for i, q in enumerate(QUIZ_DB.questions):
        chapter = q.get('الفصل', 'غير مصنف')
        lesson = q.get('الدرس', 'غير مصنف')
        
        if chapter not in questions_by_chapter:
            questions_by_chapter[chapter] = {}
        
        if lesson not in questions_by_chapter[chapter]:
            questions_by_chapter[chapter][lesson] = []
        
        questions_by_chapter[chapter][lesson].append((i, q['سؤال']))
    
    # إنشاء نص القائمة
    result = "📋 قائمة الأسئلة المخصصة:\n\n"
    
    for chapter in sorted(questions_by_chapter.keys()):
        result += f"<b>{chapter}:</b>\n"
        
        for lesson in sorted(questions_by_chapter[chapter].keys()):
            result += f"  <b>{lesson}:</b>\n"
            
            for i, (index, question) in enumerate(questions_by_chapter[chapter][lesson]):
                # تقصير السؤال إذا كان طويلاً
                short_question = question[:50] + "..." if len(question) > 50 else question
                result += f"    {index+1}. {short_question}\n"
    
    # إضافة زر العودة
    keyboard = [[InlineKeyboardButton("🔙 العودة", callback_data='menu_admin')]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    # إرسال القائمة (قد تكون طويلة)
    try:
        await update.callback_query.edit_message_text(result, reply_markup=reply_markup, parse_mode=ParseMode.HTML)
    except TelegramError as e:
        # إذا كانت الرسالة طويلة جداً، قسمها إلى أجزاء
        if "Message is too long" in str(e):
            # إرسال رسالة تنبيه
            await update.callback_query.edit_message_text(
                "قائمة الأسئلة طويلة جداً. سيتم إرسالها في عدة رسائل.",
                reply_markup=reply_markup
            )
            
            # تقسيم النص إلى أجزاء بحجم 4000 حرف
            chunks = [result[i:i+4000] for i in range(0, len(result), 4000)]
            
            for chunk in chunks:
                await update.effective_message.reply_text(chunk, parse_mode=ParseMode.HTML)
        else:
            logger.error(f"Error sending question list: {e}")
            await update.callback_query.edit_message_text(
                "حدث خطأ أثناء عرض قائمة الأسئلة.",
                reply_markup=reply_markup
            )

async def delete_question_prompt(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """طلب رقم السؤال المراد حذفه."""
    if not is_admin(update.effective_user.id):
        await update.callback_query.answer("عذراً، هذا القسم متاح للمسؤول فقط.", show_alert=True)
        return
    
    if not QUIZ_DB.questions:
        await update.callback_query.edit_message_text(
            "لا توجد أسئلة في قاعدة البيانات حالياً.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 العودة", callback_data='menu_admin')]])
        )
        return
    
    await update.callback_query.edit_message_text(
        "الرجاء إرسال رقم السؤال الذي تريد حذفه:"
    )
    
    context.user_data['next_action'] = 'delete_question_index'

async def delete_question_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE, index_str: str = None) -> None:
    """تأكيد حذف السؤال."""
    if index_str is None:
        index_str = update.message.text
    
    try:
        index = int(index_str) - 1
        
        if index < 0 or index >= len(QUIZ_DB.questions):
            await update.message.reply_text(
                f"رقم غير صالح. الرجاء إدخال رقم بين 1 و {len(QUIZ_DB.questions)}:"
            )
            context.user_data['next_action'] = 'delete_question_index'
            return
        
        question = QUIZ_DB.questions[index]
        
        # عرض تفاصيل السؤال للتأكيد
        question_text = (
            f"<b>السؤال:</b> {question['سؤال']}\n"
            f"<b>الخيارات:</b>\n"
        )
        
        for i, option in enumerate(question['خيارات']):
            if option == question['إجابة_صحيحة']:
                question_text += f"  {i+1}. {option} ✓\n"
            else:
                question_text += f"  {i+1}. {option}\n"
        
        question_text += (
            f"<b>الفصل:</b> {question.get('الفصل', 'غير محدد')}\n"
            f"<b>الدرس:</b> {question.get('الدرس', 'غير محدد')}\n\n"
            f"هل أنت متأكد من حذف هذا السؤال؟"
        )
        
        # أزرار التأكيد
        keyboard = [
            [InlineKeyboardButton("✅ نعم، احذف السؤال", callback_data=f'confirm_delete_{index}')],
            [InlineKeyboardButton("❌ لا، إلغاء العملية", callback_data='menu_admin')],
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(question_text, reply_markup=reply_markup, parse_mode=ParseMode.HTML)
    
    except ValueError:
        await update.message.reply_text(
            "إدخال غير صالح. الرجاء إدخال رقم السؤال:"
        )
        context.user_data['next_action'] = 'delete_question_index'

async def delete_question_execute(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """تنفيذ حذف السؤال."""
    query = update.callback_query
    await query.answer()
    
    data = query.data.split("_")
    index = int(data[2])
    
    # حذف السؤال
    if 0 <= index < len(QUIZ_DB.questions):
        QUIZ_DB.questions.pop(index)
        QUIZ_DB.save_questions()
        
        await query.edit_message_text(
            "✅ تم حذف السؤال بنجاح.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 العودة", callback_data='menu_admin')]])
        )
    else:
        await query.edit_message_text(
            "❌ حدث خطأ أثناء حذف السؤال.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 العودة", callback_data='menu_admin')]])
        )

async def show_question_prompt(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """طلب رقم السؤال المراد عرضه."""
    if not is_admin(update.effective_user.id):
        await update.callback_query.answer("عذراً، هذا القسم متاح للمسؤول فقط.", show_alert=True)
        return
    
    if not QUIZ_DB.questions:
        await update.callback_query.edit_message_text(
            "لا توجد أسئلة في قاعدة البيانات حالياً.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 العودة", callback_data='menu_admin')]])
        )
        return
    
    await update.callback_query.edit_message_text(
        "الرجاء إرسال رقم السؤال الذي تريد عرضه:"
    )
    
    context.user_data['next_action'] = 'show_question_index'

async def show_question(update: Update, context: ContextTypes.DEFAULT_TYPE, index_str: str = None) -> None:
    """عرض تفاصيل السؤال المحدد."""
    if index_str is None:
        index_str = update.message.text
    
    try:
        index = int(index_str) - 1
        
        if index < 0 or index >= len(QUIZ_DB.questions):
            await update.message.reply_text(
                f"رقم غير صالح. الرجاء إدخال رقم بين 1 و {len(QUIZ_DB.questions)}:"
            )
            context.user_data['next_action'] = 'show_question_index'
            return
        
        question = QUIZ_DB.questions[index]
        
        # معالجة المعادلات الكيميائية
        processed_question = process_text_with_chemical_notation(question['سؤال'])
        processed_options = [process_text_with_chemical_notation(option) for option in question['خيارات']]
        processed_explanation = process_text_with_chemical_notation(question['شرح'])
        
        # عرض تفاصيل السؤال
        question_text = (
            f"<b>السؤال {index+1}:</b> {processed_question}\n\n"
            f"<b>الخيارات:</b>\n"
        )
        
        for i, option in enumerate(processed_options):
            if question['خيارات'][i] == question['إجابة_صحيحة']:
                question_text += f"  {i+1}. {option} ✓\n"
            else:
                question_text += f"  {i+1}. {option}\n"
        
        question_text += (
            f"\n<b>الشرح:</b> {processed_explanation}\n\n"
            f"<b>الفصل:</b> {question.get('الفصل', 'غير محدد')}\n"
            f"<b>الدرس:</b> {question.get('الدرس', 'غير محدد')}"
        )
        
        # أزرار إضافية
        keyboard = [
            [InlineKeyboardButton("📷 إضافة/تغيير صورة السؤال", callback_data=f'add_question_image_{index}')],
            [InlineKeyboardButton("🔙 العودة", callback_data='menu_admin')],
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(question_text, reply_markup=reply_markup, parse_mode=ParseMode.HTML)
        
        # عرض صورة السؤال إذا كانت موجودة
        if 'صورة_السؤال' in question and question['صورة_السؤال']:
            try:
                image_data = base64.b64decode(question['صورة_السؤال'])
                photo = BytesIO(image_data)
                photo.name = 'question_image.jpg'
                await update.message.reply_photo(photo=photo, caption="صورة السؤال")
            except Exception as e:
                logger.error(f"خطأ في عرض صورة السؤال: {e}")
    
    except ValueError:
        await update.message.reply_text(
            "إدخال غير صالح. الرجاء إدخال رقم السؤال:"
        )
        context.user_data['next_action'] = 'show_question_index'

# --- دوال استيراد وتصدير الأسئلة ---
async def import_questions_prompt(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """عرض خيارات استيراد الأسئلة."""
    if not is_admin(update.effective_user.id):
        await update.callback_query.answer("عذراً، هذا القسم متاح للمسؤول فقط.", show_alert=True)
        return
    
    keyboard = [
        [InlineKeyboardButton("📥 استيراد من Excel", callback_data='import_excel')],
        [InlineKeyboardButton("📥 استيراد من CSV", callback_data='import_csv')],
        [InlineKeyboardButton("🔙 العودة", callback_data='menu_admin')],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        "اختر نوع الملف الذي تريد استيراد الأسئلة منه:",
        reply_markup=reply_markup
    )

async def import_excel_prompt(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """طلب ملف Excel لاستيراد الأسئلة."""
    await update.callback_query.edit_message_text(
        "الرجاء إرسال ملف Excel (.xlsx) الذي يحتوي على الأسئلة.\n\n"
        "تأكد من أن الملف يحتوي على الأعمدة التالية:\n"
        "- السؤال\n"
        "- الخيار_1\n"
        "- الخيار_2\n"
        "- الخيار_3\n"
        "- الخيار_4\n"
        "- الإجابة_الصحيحة\n"
        "- الشرح\n"
        "- الفصل\n"
        "- الدرس\n\n"
        "يمكنك استخدام زر 'إنشاء قالب' للحصول على قالب فارغ."
    )
    
    context.user_data['next_action'] = 'import_excel_file'

async def import_csv_prompt(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """طلب ملف CSV لاستيراد الأسئلة."""
    await update.callback_query.edit_message_text(
        "الرجاء إرسال ملف CSV (.csv) الذي يحتوي على الأسئلة.\n\n"
        "تأكد من أن الملف يحتوي على الأعمدة التالية:\n"
        "- السؤال\n"
        "- الخيار_1\n"
        "- الخيار_2\n"
        "- الخيار_3\n"
        "- الخيار_4\n"
        "- الإجابة_الصحيحة\n"
        "- الشرح\n"
        "- الفصل\n"
        "- الدرس\n\n"
        "يمكنك استخدام زر 'إنشاء قالب' للحصول على قالب فارغ."
    )
    
    context.user_data['next_action'] = 'import_csv_file'

async def handle_document(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """معالجة الملفات المرسلة (Excel/CSV)."""
    if 'next_action' not in context.user_data:
        return
    
    action = context.user_data.pop('next_action')
    
    if action not in ['import_excel_file', 'import_csv_file']:
        return
    
    # التحقق من صلاحيات المستخدم
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("عذراً، هذا القسم متاح للمسؤول فقط.")
        return
    
    # الحصول على الملف
    file = await update.message.document.get_file()
    file_name = update.message.document.file_name
    
    # التحقق من نوع الملف
    if action == 'import_excel_file' and not file_name.endswith(('.xlsx', '.xls')):
        await update.message.reply_text("الملف المرسل ليس ملف Excel. الرجاء إرسال ملف بامتداد .xlsx أو .xls.")
        return
    
    if action == 'import_csv_file' and not file_name.endswith('.csv'):
        await update.message.reply_text("الملف المرسل ليس ملف CSV. الرجاء إرسال ملف بامتداد .csv.")
        return
    
    # تنزيل الملف
    temp_file_path = os.path.join(os.path.dirname(__file__), f"temp_{file_name}")
    await file.download_to_drive(temp_file_path)
    
    # استيراد الأسئلة
    try:
        if action == 'import_excel_file':
            success_count, errors = QUIZ_DB.import_from_excel(temp_file_path)
        else:  # import_csv_file
            success_count, errors = QUIZ_DB.import_from_csv(temp_file_path)
        
        # إنشاء رسالة النتيجة
        if success_count > 0:
            result_text = f"✅ تم استيراد {success_count} سؤال بنجاح."
        else:
            result_text = "❌ لم يتم استيراد أي سؤال."
        
        if errors:
            result_text += "\n\nالأخطاء التي حدثت أثناء الاستيراد:\n"
            for error in errors[:10]:  # عرض أول 10 أخطاء فقط
                result_text += f"- {error}\n"
            
            if len(errors) > 10:
                result_text += f"... و {len(errors) - 10} أخطاء أخرى."
        
        # إرسال النتيجة
        keyboard = [[InlineKeyboardButton("🔙 العودة", callback_data='menu_admin')]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(result_text, reply_markup=reply_markup)
    
    except Exception as e:
        await update.message.reply_text(f"حدث خطأ أثناء استيراد الأسئلة: {str(e)}")
    
    finally:
        # حذف الملف المؤقت
        if os.path.exists(temp_file_path):
            os.remove(temp_file_path)

async def export_questions_prompt(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """عرض خيارات تصدير الأسئلة."""
    if not is_admin(update.effective_user.id):
        await update.callback_query.answer("عذراً، هذا القسم متاح للمسؤول فقط.", show_alert=True)
        return
    
    if not QUIZ_DB.questions:
        await update.callback_query.edit_message_text(
            "لا توجد أسئلة في قاعدة البيانات حالياً.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 العودة", callback_data='menu_admin')]])
        )
        return
    
    keyboard = [
        [InlineKeyboardButton("📤 تصدير إلى Excel", callback_data='export_excel')],
        [InlineKeyboardButton("📤 تصدير إلى CSV", callback_data='export_csv')],
        [InlineKeyboardButton("🔙 العودة", callback_data='menu_admin')],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        "اختر نوع الملف الذي تريد تصدير الأسئلة إليه:",
        reply_markup=reply_markup
    )

async def export_excel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """تصدير الأسئلة إلى ملف Excel."""
    if not is_admin(update.effective_user.id):
        await update.callback_query.answer("عذراً، هذا القسم متاح للمسؤول فقط.", show_alert=True)
        return
    
    await update.callback_query.answer("جاري تصدير الأسئلة...")
    
    # إنشاء DataFrame من الأسئلة
    data = []
    for q in QUIZ_DB.questions:
        row = {
            'السؤال': q['سؤال'],
            'الخيار_1': q['خيارات'][0],
            'الخيار_2': q['خيارات'][1],
            'الخيار_3': q['خيارات'][2],
            'الخيار_4': q['خيارات'][3],
            'الإجابة_الصحيحة': q['إجابة_صحيحة'],
            'الشرح': q['شرح'],
            'الفصل': q.get('الفصل', ''),
            'الدرس': q.get('الدرس', '')
        }
        
        # إضافة الصور إذا كانت موجودة
        if 'صورة_السؤال' in q:
            row['صورة_السؤال'] = q['صورة_السؤال']
        
        if 'صور_الخيارات' in q:
            for i, img in enumerate(q['صور_الخيارات']):
                if img:
                    row[f'صورة_الخيار_{i+1}'] = img
        
        data.append(row)
    
    import pandas as pd
    df = pd.DataFrame(data)
    
    # حفظ DataFrame إلى ملف Excel
    output_file = os.path.join(os.path.dirname(__file__), "exported_questions.xlsx")
    df.to_excel(output_file, index=False)
    
    # إرسال الملف
    await update.effective_message.reply_document(
        document=open(output_file, 'rb'),
        filename="exported_questions.xlsx",
        caption="تم تصدير الأسئلة بنجاح."
    )
    
    # حذف الملف المؤقت
    os.remove(output_file)
    
    # إظهار قائمة الإدارة مرة أخرى
    keyboard = [[InlineKeyboardButton("🔙 العودة", callback_data='menu_admin')]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.effective_message.reply_text(
        "تم تصدير الأسئلة بنجاح. ماذا تريد أن تفعل الآن؟",
        reply_markup=reply_markup
    )

async def export_csv(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """تصدير الأسئلة إلى ملف CSV."""
    if not is_admin(update.effective_user.id):
        await update.callback_query.answer("عذراً، هذا القسم متاح للمسؤول فقط.", show_alert=True)
        return
    
    await update.callback_query.answer("جاري تصدير الأسئلة...")
    
    # إنشاء DataFrame من الأسئلة
    data = []
    for q in QUIZ_DB.questions:
        row = {
            'السؤال': q['سؤال'],
            'الخيار_1': q['خيارات'][0],
            'الخيار_2': q['خيارات'][1],
            'الخيار_3': q['خيارات'][2],
            'الخيار_4': q['خيارات'][3],
            'الإجابة_الصحيحة': q['إجابة_صحيحة'],
            'الشرح': q['شرح'],
            'الفصل': q.get('الفصل', ''),
            'الدرس': q.get('الدرس', '')
        }
        
        # إضافة الصور إذا كانت موجودة
        if 'صورة_السؤال' in q:
            row['صورة_السؤال'] = q['صورة_السؤال']
        
        if 'صور_الخيارات' in q:
            for i, img in enumerate(q['صور_الخيارات']):
                if img:
                    row[f'صورة_الخيار_{i+1}'] = img
        
        data.append(row)
    
    import pandas as pd
    df = pd.DataFrame(data)
    
    # حفظ DataFrame إلى ملف CSV
    output_file = os.path.join(os.path.dirname(__file__), "exported_questions.csv")
    df.to_csv(output_file, index=False, encoding='utf-8-sig')
    
    # إرسال الملف
    await update.effective_message.reply_document(
        document=open(output_file, 'rb'),
        filename="exported_questions.csv",
        caption="تم تصدير الأسئلة بنجاح."
    )
    
    # حذف الملف المؤقت
    os.remove(output_file)
    
    # إظهار قائمة الإدارة مرة أخرى
    keyboard = [[InlineKeyboardButton("🔙 العودة", callback_data='menu_admin')]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.effective_message.reply_text(
        "تم تصدير الأسئلة بنجاح. ماذا تريد أن تفعل الآن؟",
        reply_markup=reply_markup
    )

async def create_template_prompt(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """عرض خيارات إنشاء قالب."""
    if not is_admin(update.effective_user.id):
        await update.callback_query.answer("عذراً، هذا القسم متاح للمسؤول فقط.", show_alert=True)
        return
    
    keyboard = [
        [InlineKeyboardButton("📄 قالب Excel", callback_data='create_excel_template')],
        [InlineKeyboardButton("📄 قالب CSV", callback_data='create_csv_template')],
        [InlineKeyboardButton("🔙 العودة", callback_data='menu_admin')],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.callback_query.edit_message_text(
        "اختر نوع القالب الذي تريد إنشاءه:",
        reply_markup=reply_markup
    )

async def create_excel_template(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """إنشاء قالب Excel."""
    if not is_admin(update.effective_user.id):
        await update.callback_query.answer("عذراً، هذا القسم متاح للمسؤول فقط.", show_alert=True)
        return
    
    await update.callback_query.answer("جاري إنشاء القالب...")
    
    # إنشاء قالب Excel
    output_file = os.path.join(os.path.dirname(__file__), "questions_template.xlsx")
    success = QUIZ_DB.create_excel_template(output_file)
    
    if success:
        # إرسال الملف
        await update.effective_message.reply_document(
            document=open(output_file, 'rb'),
            filename="questions_template.xlsx",
            caption="تم إنشاء قالب Excel بنجاح. استخدم هذا القالب لإضافة أسئلة جديدة."
        )
        
        # حذف الملف المؤقت
        os.remove(output_file)
    else:
        await update.effective_message.reply_text("حدث خطأ أثناء إنشاء قالب Excel.")
    
    # إظهار قائمة الإدارة مرة أخرى
    keyboard = [[InlineKeyboardButton("🔙 العودة", callback_data='menu_admin')]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.effective_message.reply_text(
        "ماذا تريد أن تفعل الآن؟",
        reply_markup=reply_markup
    )

async def create_csv_template(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """إنشاء قالب CSV."""
    if not is_admin(update.effective_user.id):
        await update.callback_query.answer("عذراً، هذا القسم متاح للمسؤول فقط.", show_alert=True)
        return
    
    await update.callback_query.answer("جاري إنشاء القالب...")
    
    # إنشاء قالب CSV
    output_file = os.path.join(os.path.dirname(__file__), "questions_template.csv")
    success = QUIZ_DB.create_csv_template(output_file)
    
    if success:
        # إرسال الملف
        await update.effective_message.reply_document(
            document=open(output_file, 'rb'),
            filename="questions_template.csv",
            caption="تم إنشاء قالب CSV بنجاح. استخدم هذا القالب لإضافة أسئلة جديدة."
        )
        
        # إرسال ملف التعليمات
        instructions_file = os.path.splitext(output_file)[0] + '_تعليمات.txt'
        if os.path.exists(instructions_file):
            await update.effective_message.reply_document(
                document=open(instructions_file, 'rb'),
                filename="questions_template_instructions.txt",
                caption="تعليمات استخدام قالب CSV."
            )
            
            # حذف ملف التعليمات المؤقت
            os.remove(instructions_file)
        
        # حذف الملف المؤقت
        os.remove(output_file)
    else:
        await update.effective_message.reply_text("حدث خطأ أثناء إنشاء قالب CSV.")
    
    # إظهار قائمة الإدارة مرة أخرى
    keyboard = [[InlineKeyboardButton("🔙 العودة", callback_data='menu_admin')]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.effective_message.reply_text(
        "ماذا تريد أن تفعل الآن؟",
        reply_markup=reply_markup
    )

# --- الدالة الرئيسية ---
def main() -> None:
    """تشغيل البوت."""
    # إنشاء تطبيق
    application = Application.builder().token(os.environ.get("TOKEN")).build()

    # إضافة معالجات الأوامر
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("about", about_command))
    application.add_handler(CommandHandler("id", id_command))
    application.add_handler(CommandHandler("element", element_command))
    application.add_handler(CommandHandler("compound", compound_command))
    application.add_handler(CommandHandler("concept", concept_command))
    application.add_handler(CommandHandler("periodic", periodic_table_command))
    application.add_handler(CommandHandler("calculations", calculations_command))
    application.add_handler(CommandHandler("bonds", bonds_command))
    application.add_handler(CommandHandler("quiz", quiz_command))

    # إضافة معالج محادثة إضافة سؤال
    add_question_conv_handler = ConversationHandler(
        entry_points=[CallbackQueryHandler(add_question_start, pattern='^admin_add$')],
        states={
            QUESTION: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_question_text)],
            OPTIONS: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_question_options)],
            CORRECT_ANSWER: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_question_correct_answer)],
            EXPLANATION: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_question_explanation)],
            CHAPTER: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_question_chapter)],
            LESSON: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_question_lesson)],
        },
        fallbacks=[CommandHandler("cancel", add_question_cancel)],
    )
    application.add_handler(add_question_conv_handler)

    # إضافة معالجات أزرار القوائم
    application.add_handler(CallbackQueryHandler(main_menu_button_handler, pattern='^main_menu$'))
    application.add_handler(CallbackQueryHandler(main_menu_button_handler, pattern='^menu_'))
    application.add_handler(CallbackQueryHandler(main_menu_button_handler, pattern='^info_'))
    application.add_handler(CallbackQueryHandler(builtin_quiz_button, pattern='^builtin_quiz_'))
    application.add_handler(CallbackQueryHandler(custom_quiz_button, pattern='^custom_quiz_'))
    application.add_handler(CallbackQueryHandler(main_menu_button_handler, pattern='^quiz_'))
    application.add_handler(CallbackQueryHandler(main_menu_button_handler, pattern='^admin_'))
    application.add_handler(CallbackQueryHandler(delete_question_execute, pattern='^confirm_delete_'))
    
    # إضافة معالجات استيراد وتصدير الأسئلة
    application.add_handler(CallbackQueryHandler(import_excel_prompt, pattern='^import_excel$'))
    application.add_handler(CallbackQueryHandler(import_csv_prompt, pattern='^import_csv$'))
    application.add_handler(CallbackQueryHandler(export_excel, pattern='^export_excel$'))
    application.add_handler(CallbackQueryHandler(export_csv, pattern='^export_csv$'))
    application.add_handler(CallbackQueryHandler(create_excel_template, pattern='^create_excel_template$'))
    application.add_handler(CallbackQueryHandler(create_csv_template, pattern='^create_csv_template$'))
    
    # إضافة معالج الملفات
    application.add_handler(MessageHandler(filters.Document.ALL, handle_document))

    # إضافة معالج النصوص (للبحث عن عناصر/مركبات/مفاهيم)
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text_input))

    # بدء البوت
    application.run_polling()

if __name__ == "__main__":
    main()
