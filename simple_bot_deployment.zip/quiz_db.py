#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
import os
import random
import pandas as pd
import csv
import base64
from io import BytesIO

class QuizDatabase:
    """
    قاعدة بيانات للأسئلة والاختبارات.
    """
    
    def __init__(self, file_path):
        """
        تهيئة قاعدة البيانات.
        
        المعلمات:
            file_path (str): مسار ملف JSON لتخزين الأسئلة.
        """
        self.file_path = file_path
        self.questions = []
        self.load_questions()
    
    def load_questions(self):
        """
        تحميل الأسئلة من ملف JSON.
        """
        if os.path.exists(self.file_path):
            try:
                with open(self.file_path, 'r', encoding='utf-8') as f:
                    self.questions = json.load(f)
            except json.JSONDecodeError:
                print(f"خطأ في تنسيق ملف JSON: {self.file_path}")
                self.questions = []
        else:
            self.questions = []
    
    def save_questions(self):
        """
        حفظ الأسئلة إلى ملف JSON.
        """
        with open(self.file_path, 'w', encoding='utf-8') as f:
            json.dump(self.questions, f, ensure_ascii=False, indent=4)
    
    def add_question(self, question, options, correct_answer, explanation, chapter=None, lesson=None, question_image=None, option_images=None):
        """
        إضافة سؤال جديد إلى قاعدة البيانات.
        
        المعلمات:
            question (str): نص السؤال.
            options (list): قائمة بالخيارات.
            correct_answer (str): الإجابة الصحيحة (يجب أن تكون أحد الخيارات).
            explanation (str): شرح الإجابة.
            chapter (str, optional): اسم الفصل.
            lesson (str, optional): اسم الدرس.
            question_image (str, optional): صورة السؤال (base64).
            option_images (list, optional): قائمة بصور الخيارات (base64).
        
        العائد:
            bool: True إذا تمت الإضافة بنجاح، False خلاف ذلك.
        """
        if len(options) != 4:
            print("يجب أن يكون هناك 4 خيارات بالضبط.")
            return False
        
        if correct_answer not in options:
            print("الإجابة الصحيحة يجب أن تكون أحد الخيارات.")
            return False
        
        question_data = {
            "سؤال": question,
            "خيارات": options,
            "إجابة_صحيحة": correct_answer,
            "شرح": explanation
        }
        
        if chapter:
            question_data["الفصل"] = chapter
        
        if lesson:
            question_data["الدرس"] = lesson
        
        if question_image:
            question_data["صورة_السؤال"] = question_image
        
        if option_images:
            question_data["صور_الخيارات"] = option_images
        
        self.questions.append(question_data)
        self.save_questions()
        return True
    
    def get_random_question(self, chapter=None, lesson=None):
        """
        الحصول على سؤال عشوائي من قاعدة البيانات.
        
        المعلمات:
            chapter (str, optional): اسم الفصل للتصفية.
            lesson (str, optional): اسم الدرس للتصفية.
        
        العائد:
            dict: بيانات السؤال.
        """
        filtered_questions = self.questions
        
        if chapter:
            filtered_questions = [q for q in filtered_questions if q.get("الفصل") == chapter]
        
        if lesson:
            filtered_questions = [q for q in filtered_questions if q.get("الدرس") == lesson]
        
        if not filtered_questions:
            return None
        
        return random.choice(filtered_questions)
    
    def get_question_by_index(self, index):
        """
        الحصول على سؤال بواسطة الفهرس.
        
        المعلمات:
            index (int): فهرس السؤال.
        
        العائد:
            dict: بيانات السؤال.
        """
        if 0 <= index < len(self.questions):
            return self.questions[index]
        return None
    
    def update_question(self, index, question=None, options=None, correct_answer=None, explanation=None, chapter=None, lesson=None, question_image=None, option_images=None):
        """
        تحديث سؤال موجود.
        
        المعلمات:
            index (int): فهرس السؤال.
            question (str, optional): نص السؤال الجديد.
            options (list, optional): قائمة بالخيارات الجديدة.
            correct_answer (str, optional): الإجابة الصحيحة الجديدة.
            explanation (str, optional): شرح الإجابة الجديد.
            chapter (str, optional): اسم الفصل الجديد.
            lesson (str, optional): اسم الدرس الجديد.
            question_image (str, optional): صورة السؤال الجديدة (base64).
            option_images (list, optional): قائمة بصور الخيارات الجديدة (base64).
        
        العائد:
            bool: True إذا تم التحديث بنجاح، False خلاف ذلك.
        """
        if not 0 <= index < len(self.questions):
            return False
        
        if question:
            self.questions[index]["سؤال"] = question
        
        if options:
            if len(options) != 4:
                print("يجب أن يكون هناك 4 خيارات بالضبط.")
                return False
            self.questions[index]["خيارات"] = options
        
        if correct_answer:
            if options and correct_answer not in options:
                print("الإجابة الصحيحة يجب أن تكون أحد الخيارات.")
                return False
            elif not options and correct_answer not in self.questions[index]["خيارات"]:
                print("الإجابة الصحيحة يجب أن تكون أحد الخيارات.")
                return False
            self.questions[index]["إجابة_صحيحة"] = correct_answer
        
        if explanation:
            self.questions[index]["شرح"] = explanation
        
        if chapter:
            self.questions[index]["الفصل"] = chapter
        
        if lesson:
            self.questions[index]["الدرس"] = lesson
        
        if question_image:
            self.questions[index]["صورة_السؤال"] = question_image
        
        if option_images:
            self.questions[index]["صور_الخيارات"] = option_images
        
        self.save_questions()
        return True
    
    def delete_question(self, index):
        """
        حذف سؤال من قاعدة البيانات.
        
        المعلمات:
            index (int): فهرس السؤال.
        
        العائد:
            bool: True إذا تم الحذف بنجاح، False خلاف ذلك.
        """
        if not 0 <= index < len(self.questions):
            return False
        
        self.questions.pop(index)
        self.save_questions()
        return True
    
    def get_chapters(self):
        """
        الحصول على قائمة بجميع الفصول المتاحة.
        
        العائد:
            list: قائمة بأسماء الفصول.
        """
        chapters = set()
        for q in self.questions:
            if "الفصل" in q:
                chapters.add(q["الفصل"])
        return sorted(list(chapters))
    
    def get_lessons(self, chapter=None):
        """
        الحصول على قائمة بجميع الدروس المتاحة.
        
        المعلمات:
            chapter (str, optional): اسم الفصل للتصفية.
        
        العائد:
            list: قائمة بأسماء الدروس.
        """
        lessons = set()
        for q in self.questions:
            if "الدرس" in q:
                if chapter is None or q.get("الفصل") == chapter:
                    lessons.add(q["الدرس"])
        return sorted(list(lessons))
    
    def import_from_excel(self, file_path):
        """
        استيراد أسئلة من ملف Excel.
        
        المعلمات:
            file_path (str): مسار ملف Excel.
        
        العائد:
            tuple: (عدد الأسئلة المستوردة بنجاح, قائمة بالأخطاء)
        """
        try:
            df = pd.read_excel(file_path)
            return self._import_from_dataframe(df)
        except Exception as e:
            return 0, [f"خطأ في قراءة ملف Excel: {str(e)}"]
    
    def import_from_csv(self, file_path):
        """
        استيراد أسئلة من ملف CSV.
        
        المعلمات:
            file_path (str): مسار ملف CSV.
        
        العائد:
            tuple: (عدد الأسئلة المستوردة بنجاح, قائمة بالأخطاء)
        """
        try:
            df = pd.read_csv(file_path, encoding='utf-8-sig')
            return self._import_from_dataframe(df)
        except Exception as e:
            return 0, [f"خطأ في قراءة ملف CSV: {str(e)}"]
    
    def _import_from_dataframe(self, df):
        """
        استيراد أسئلة من DataFrame.
        
        المعلمات:
            df (pandas.DataFrame): DataFrame يحتوي على الأسئلة.
        
        العائد:
            tuple: (عدد الأسئلة المستوردة بنجاح, قائمة بالأخطاء)
        """
        success_count = 0
        errors = []
        
        # التحقق من وجود الأعمدة المطلوبة
        required_columns = ['السؤال', 'الخيار_1', 'الخيار_2', 'الخيار_3', 'الخيار_4', 'الإجابة_الصحيحة', 'الشرح']
        for col in required_columns:
            if col not in df.columns:
                return 0, [f"العمود المطلوب '{col}' غير موجود في الملف."]
        
        # معالجة كل صف
        for i, row in df.iterrows():
            try:
                # استخراج البيانات
                question = row['السؤال']
                options = [row['الخيار_1'], row['الخيار_2'], row['الخيار_3'], row['الخيار_4']]
                correct_answer = row['الإجابة_الصحيحة']
                explanation = row['الشرح']
                
                # التحقق من البيانات الإلزامية
                if pd.isna(question) or question == '':
                    errors.append(f"الصف {i+1}: السؤال فارغ.")
                    continue
                
                if any(pd.isna(opt) or opt == '' for opt in options):
                    errors.append(f"الصف {i+1}: أحد الخيارات فارغ.")
                    continue
                
                if pd.isna(correct_answer) or correct_answer == '':
                    errors.append(f"الصف {i+1}: الإجابة الصحيحة فارغة.")
                    continue
                
                if correct_answer not in options:
                    errors.append(f"الصف {i+1}: الإجابة الصحيحة ليست أحد الخيارات.")
                    continue
                
                if pd.isna(explanation) or explanation == '':
                    errors.append(f"الصف {i+1}: الشرح فارغ.")
                    continue
                
                # استخراج البيانات الاختيارية
                chapter = row.get('الفصل', None)
                if pd.isna(chapter):
                    chapter = None
                
                lesson = row.get('الدرس', None)
                if pd.isna(lesson):
                    lesson = None
                
                # استخراج الصور إذا كانت موجودة
                question_image = row.get('صورة_السؤال', None)
                if pd.isna(question_image):
                    question_image = None
                
                option_images = []
                for j in range(1, 5):
                    img = row.get(f'صورة_الخيار_{j}', None)
                    if pd.isna(img):
                        img = None
                    option_images.append(img)
                
                if all(img is None for img in option_images):
                    option_images = None
                
                # إضافة السؤال
                question_data = {
                    "سؤال": question,
                    "خيارات": options,
                    "إجابة_صحيحة": correct_answer,
                    "شرح": explanation
                }
                
                if chapter:
                    question_data["الفصل"] = chapter
                
                if lesson:
                    question_data["الدرس"] = lesson
                
                if question_image:
                    question_data["صورة_السؤال"] = question_image
                
                if option_images:
                    question_data["صور_الخيارات"] = option_images
                
                self.questions.append(question_data)
                success_count += 1
            
            except Exception as e:
                errors.append(f"الصف {i+1}: {str(e)}")
        
        # حفظ التغييرات إذا تم استيراد أي سؤال بنجاح
        if success_count > 0:
            self.save_questions()
        
        return success_count, errors
    
    def create_excel_template(self, output_file):
        """
        إنشاء قالب Excel فارغ.
        
        المعلمات:
            output_file (str): مسار ملف الإخراج.
        
        العائد:
            bool: True إذا تم الإنشاء بنجاح، False خلاف ذلك.
        """
        try:
            # إنشاء DataFrame فارغ مع الأعمدة المطلوبة
            columns = [
                'السؤال', 'الخيار_1', 'الخيار_2', 'الخيار_3', 'الخيار_4',
                'الإجابة_الصحيحة', 'الشرح', 'الفصل', 'الدرس',
                'صورة_السؤال', 'صورة_الخيار_1', 'صورة_الخيار_2', 'صورة_الخيار_3', 'صورة_الخيار_4'
            ]
            
            # إضافة صف مثال
            data = [{
                'السؤال': 'ما هو العنصر الذي رمزه H؟',
                'الخيار_1': 'هيدروجين',
                'الخيار_2': 'هيليوم',
                'الخيار_3': 'نيتروجين',
                'الخيار_4': 'أكسجين',
                'الإجابة_الصحيحة': 'هيدروجين',
                'الشرح': 'الهيدروجين هو العنصر الأول في الجدول الدوري ورمزه H.',
                'الفصل': 'الفصل الأول',
                'الدرس': 'العناصر الكيميائية',
                'صورة_السؤال': '',
                'صورة_الخيار_1': '',
                'صورة_الخيار_2': '',
                'صورة_الخيار_3': '',
                'صورة_الخيار_4': ''
            }]
            
            df = pd.DataFrame(data, columns=columns)
            
            # حفظ DataFrame إلى ملف Excel
            df.to_excel(output_file, index=False)
            
            return True
        except Exception as e:
            print(f"خطأ في إنشاء قالب Excel: {str(e)}")
            return False
    
    def create_csv_template(self, output_file):
        """
        إنشاء قالب CSV فارغ.
        
        المعلمات:
            output_file (str): مسار ملف الإخراج.
        
        العائد:
            bool: True إذا تم الإنشاء بنجاح، False خلاف ذلك.
        """
        try:
            # إنشاء DataFrame فارغ مع الأعمدة المطلوبة
            columns = [
                'السؤال', 'الخيار_1', 'الخيار_2', 'الخيار_3', 'الخيار_4',
                'الإجابة_الصحيحة', 'الشرح', 'الفصل', 'الدرس',
                'صورة_السؤال', 'صورة_الخيار_1', 'صورة_الخيار_2', 'صورة_الخيار_3', 'صورة_الخيار_4'
            ]
            
            # إضافة صف مثال
            data = [{
                'السؤال': 'ما هو العنصر الذي رمزه H؟',
                'الخيار_1': 'هيدروجين',
                'الخيار_2': 'هيليوم',
                'الخيار_3': 'نيتروجين',
                'الخيار_4': 'أكسجين',
                'الإجابة_الصحيحة': 'هيدروجين',
                'الشرح': 'الهيدروجين هو العنصر الأول في الجدول الدوري ورمزه H.',
                'الفصل': 'الفصل الأول',
                'الدرس': 'العناصر الكيميائية',
                'صورة_السؤال': '',
                'صورة_الخيار_1': '',
                'صورة_الخيار_2': '',
                'صورة_الخيار_3': '',
                'صورة_الخيار_4': ''
            }]
            
            df = pd.DataFrame(data, columns=columns)
            
            # حفظ DataFrame إلى ملف CSV
            df.to_csv(output_file, index=False, encoding='utf-8-sig')
            
            # إنشاء ملف تعليمات
            instructions_file = os.path.splitext(output_file)[0] + '_تعليمات.txt'
            with open(instructions_file, 'w', encoding='utf-8') as f:
                f.write("""تعليمات استخدام قالب CSV لإضافة أسئلة:

1. افتح الملف باستخدام برنامج Excel أو أي برنامج مشابه.
2. أدخل بيانات الأسئلة في الأعمدة المناسبة:
   - السؤال: نص السؤال
   - الخيار_1 إلى الخيار_4: الخيارات الأربعة للسؤال
   - الإجابة_الصحيحة: يجب أن تكون مطابقة تماماً لأحد الخيارات
   - الشرح: شرح الإجابة الصحيحة
   - الفصل: اسم الفصل (اختياري)
   - الدرس: اسم الدرس (اختياري)
   - صورة_السؤال: رابط أو بيانات base64 للصورة (اختياري)
   - صورة_الخيار_1 إلى صورة_الخيار_4: روابط أو بيانات base64 للصور (اختياري)

3. احفظ الملف بتنسيق CSV (UTF-8).
4. أرسل الملف إلى البوت لاستيراد الأسئلة.

ملاحظات هامة:
- تأكد من أن الإجابة الصحيحة مطابقة تماماً لأحد الخيارات.
- لا تترك أي خلية فارغة في الأعمدة الإلزامية (السؤال، الخيارات، الإجابة الصحيحة، الشرح).
- يمكنك إضافة أكثر من سؤال بإضافة صفوف جديدة.
- لإضافة صور، يمكنك استخدام روابط مباشرة للصور أو تحويلها إلى تنسيق base64.
""")
            
            return True
        except Exception as e:
            print(f"خطأ في إنشاء قالب CSV: {str(e)}")
            return False
