#!/bin/bash

# سكريبت تثبيت بوت كيمياء تحصيلي على PythonAnywhere
# هذا السكريبت يقوم بتثبيت وإعداد البوت بشكل تلقائي

echo "بدء تثبيت بوت كيمياء تحصيلي..."

# تثبيت المكتبات المطلوبة
echo "تثبيت المكتبات المطلوبة..."
pip3 install --user python-telegram-bot==13.15 pandas==1.5.3 openpyxl==3.1.2 sympy==1.12
pip3 install --user python-telegram-bot[socks] python-telegram-bot[rate-limiter] python-telegram-bot[job-queue]

# إنشاء ملف لتشغيل البوت
echo "إنشاء ملف تشغيل البوت..."
cat > run_bot.sh << 'EOL'
#!/bin/bash
cd "$(dirname "$0")"
python3 bot_with_retry.py
EOL

# جعل ملف التشغيل قابل للتنفيذ
chmod +x run_bot.sh

echo "تم الانتهاء من التثبيت بنجاح!"
echo "لتشغيل البوت، استخدم الأمر: ./run_bot.sh"
echo "لإعداد مهمة مجدولة، استخدم الأمر التالي في قسم Tasks على PythonAnywhere:"
echo "cd ~/telegram_bot && python3 bot_with_retry.py"
